<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

/* Zobrazenie stranky pre zakaznika */
Route::get('/', 'GuestController@index');

Route::get('/movies','MovieController@index');
Route::get('/news','MovieController@news');

/* Zobrazenie saly k filmu a rezervacia sedadiel */

Route::get('/film/{id}','GuestController@film');

Route::post('/ticket','GuestController@ticket');

Auth::routes();

Route::group(['middleware' => 'prevent-back-history'],function(){
  Auth::routes();
  Route::post('/show','GuestController@showInfo');
});

Route::get('/users/logout', 'Auth\LoginController@logout')->name('user.logout');
Route::get('/admin/logout', 'Auth\AdminLoginController@logout')->name('admin.logout');


/* ------------------------------Manazerske funkcie----------------------------- */
Route::prefix('admin')->group(function(){

	/* Zmena hesla usera */
	Route::get('/changepassword','AdminController@changepass');
	Route::post('change/password','AdminController@changepassword');

	/* Pridanie novych uzivatelov */
	Route::get('/insert', 'Admin\HomeController@insertView');
	Route::post('/insert','AdminController@insert');
	Route::post('/insertadmin','AdminController@insertadmin');

    /* Zmazanie zaznamov */
	Route::get('/delete/{id}', 'AdminController@delete');
	Route::get('/deleteadmin/{id}', 'AdminController@deleteadmin');
	Route::get('/deleteevents/{id}', 'Admin\EventsController@deleteevents');
	Route::get('/deletemovie/{id}', 'Admin\MovieController@deletemovie');
	Route::get('/deleteshow/{id}', 'Admin\MovieController@deleteshow');
	Route::get('/deletereservation/{id}', 'Admin\HomeController@deletereservation');
	
	/* Default laravel login */
	Route::get('/login', 'Auth\AdminLoginController@showLoginForm')->name('admin.login');
	Route::post('/login', 'Auth\AdminLoginController@login')->name('admin.login.submit');

	/* ----------------------------------------------------------------------------*/ 
	/* Vyhladavanie + filtre + pagination */

	Route::get('/showreservation/{id}','Admin\HomeController@showreservation');
	Route::get('/confirmreservation/{id}', 'Admin\HomeController@confirmreservation');
	Route::get('/reservationlist','Admin\HomeController@reservationlist');
	Route::any('/reservationlist/search','Admin\HomeController@reservationsearch');

	Route::get('/list','Admin\HomeController@userlist');
	Route::any('/list/search','Admin\HomeController@usersearch');

	Route::get('/movielist','Admin\MovieController@movielist');
	Route::any('/movielist/search','Admin\MovieController@moviesearch');

	Route::get('/showlist','Admin\MovieController@showlist');
	Route::any('/showlist/search','Admin\MovieController@showsearch');

	Route::get('/eventslistrequest','Admin\EventsController@eventsearchrequest');
	Route::any('/eventslistrequest/search','Admin\EventsController@searchrequest');

	Route::get('/eventslistconfirm','Admin\EventsController@eventsearchconfirm');
	Route::any('/eventslistconfirm/search','Admin\EventsController@searchconfirm');
	/* ----------------------------------------------------------------------------*/ 

	/* Kalendar + pridanie zaznamu */
	Route::get('/events','Admin\EventsController@index')->name('admin.events.index');
	Route::post('/events','Admin\EventsController@addEvent')->name('admin.events.add');

	/* Pridanie filmu */
	Route::get('/insertmovie', 'Admin\MovieController@insertmovieView');
	Route::post('/insertmovie','Admin\MovieController@insertmovie');

	/* Pridanie premietania + sala + sedadla */
	Route::get('/insertshow/{id}','Admin\MovieController@insertshowView');
	Route::post('/insertshow','Admin\MovieController@insertshow');

	/* Edit eventov */
	Route::get('editevents/{id}', 'Admin\EventsController@editevents')->name('admin.editevents');
	Route::post('updateevents','Admin\EventsController@updateevents');

	/* Edit filmov */
	Route::get('editmovies/{id}', 'Admin\MovieController@editmovies')->name('admin.editmovies');
	Route::post('updatemovies','Admin\MovieController@updatemovies');

	/* Edit filmov */
	Route::get('editshow/{id}', 'Admin\MovieController@editshow');
	Route::post('updateshow','Admin\MovieController@updateshow');
	
	/* Edit manazera */
	Route::get('editself/{id}', 'AdminController@editself')->name('admin.editself');
	Route::post('updateself','AdminController@updateself');
	
	/* Edit usera ako manazer*/
	Route::get('/edit/{id}', 'AdminController@edit')->name('admin.edit');
	Route::post('/update','AdminController@update');
	
	Route::get('/', 'AdminController@index')->name('admin.dashboard');
});

/* ------------------------------Uzivatelske funkcie----------------------------- */

/* Zmena hesla usera */
Route::get('/changepassword','UserController@changepass');
Route::post('change/password','UserController@changepassword');

/* Edit usera */
Route::get('/editself/{id}', 'UserController@edit')->name('home.edit');
Route::post('/updateself','UserController@updateself');

/* Delete eventov */
Route::get('/deleteevents/{id}', 'EventsController@deleteevents');

/* Kalendar + pridanie zaznamu */
Route::get('/events','EventsController@index')->name('events.index');
Route::post('/events','EventsController@addEvent')->name('events.add');

/* Edit eventov */
Route::get('/editevents/{id}', 'EventsController@editevents')->name('home.editevents');
Route::post('/updateevents','EventsController@updateevents');

/* Kontakt, home, eventslist */
Route::get('/contact', 'HomeController@contact');
Route::get('/home', 'HomeController@index')->name('home');
Route::get('/eventslist','HomeController@eventslist');












