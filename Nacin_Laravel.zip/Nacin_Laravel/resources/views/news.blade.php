  @extends('layouts.movie')

  @section('style')
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.css"/>
  @endsection

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <!------ Include the above in your HEAD tag ---------->

  <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css" rel="stylesheet">

@section('content')
  <div class="container">
    <div class="panel panel-primary">
      <div class="panel-heading"></div>
      <div class="panel-body"> 
        <div class="row">
          <div class="col-md-12 col-md-offset-1">
            <div class="top-margin-header panel heading"><h1 class="h1-bigger text-center text-white">Už čoskoro!</h1></div>
            <div class="row">
              @foreach($movies as $movie)
                <div class="col-lg-4 col-md-5 col-sm-7">
                  <article class="card">
                    <h2 class="bot-no-margin card-title p-3 mb-2 bg-dark text-white text-center">{{ $movie->title }}</h2>
                    <div class="card-block">
                      <div class="img-card">
                        <img src="{{$movie->image}}" alt="Movie" class="w-100" />
                      </div>
                      <h5 class="bot-no-margin p-3 mb-2 bg-dark text-white tagline card-text text-xs-center text-center">Premiéra: {{date("d.m.Y", strtotime($movie->date))}}<br> Žáner: {{ $movie->genre }}</h5>
                      <textarea class="bot-no-margin form-control mb-2 mr-sm-2" rows="6" cols="20" name="info" readonly>{{ $movie->info }}</textarea>
                    </div>
                  </article>
                  <br>
                </div>
              @endforeach
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>  
@endsection


