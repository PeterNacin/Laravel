@extends('layouts.admincalendar')

@section('content')

 	<div class="container">
    	<div class="panel panel-primary">
       		<div class="panel-heading"></div>
          	<div class="panel-body"> 
				<div class="row">
					<div class="col-md-10 col-xs-12 col-md-offset-1 col-xs-offset-0">
						<div class="panel heading"><h4>Zoznam zamestnancov</h4></div>
						<div class="row">
							<div class="col-md-6 col-xs-12">
								<strong>Zoradiť:  </strong>
								Floor <a href="/admin/list/?floor=1">Áno</a> |
								<a href="/admin/list/?floor=0">Nie</a> ---
								Buffet <a href="/admin/list/?buffet=1">Áno</a> |
								<a href="/admin/list/?buffet=0">Nie</a> ---
								Pokladňa <a href="/admin/list/?pokladna=1">Áno</a> |
								<a href="/admin/list/?pokladna=0">Nie</a> ---
								<a href="/admin/list/">Obnoviť</a>
							</div>
							<div class="col-md-6 col-xs-6">
								<strong> Mená: </strong>
								<a href="/admin/list/?sort=asc">Vzostupne</a> |
								<a href="/admin/list/?sort=desc">Zostupne</a>
							</div>
							<ul class="navbar-nav ml-auto">
								<div class="col-md-10 col-xs-12">
									
                        			        <form action="/admin/list/search" method="POST" role="search">
    											{{ csrf_field() }}
			    								<div class="input-group">
       												<input type="text" class="form-control" name="q"
            										placeholder="Vyhľadať zamestnanca"> <span class="input-group-btn">
            										<button type="submit" class="btn btn-default">
                									<span class="glyphicon glyphicon-search"></span></button></span>
	    										</div>
											</form>
                            			
								</div>
							</ul>
						</div>
						@if(isset($users))
						<div class="panel-body">
							<div class="col-md-12 col-xs-12 scroll">
								<table class="table">
  									<thead>
    									<tr>
      										<th scope="col">Meno</th>
    										<th scope="col">Email</th> 
    										<th scope="col">Číslo</th> 
    										<th scope="col">Floor</th> 
    										<th scope="col">Buffet</th> 
    										<th scope="col">Pokladňa</th>
    									</tr>
  									</thead>
  									<tbody>
  										@foreach($users as $user)
    									<tr>
											<td>{{ $user->name }}</td>
											<td>{{ $user->email }}</td>
											<td>{{ $user->phone }}</td>
											<td>@if($user->floor == '1') Áno  @else Nie @endif </td>
											<td>@if($user->buffet == '1') Áno  @else Nie @endif </td>
											<td>@if($user->pokladna == '1') Áno  @else Nie @endif </td>
											<td><a href="{{ url('/admin/edit',$user->id)}}">Upraviť</a></td>
											<td><a href="/admin/delete/{{$user->id}}'" onclick="return confirm('Skutočne chcete tento záznam vymazať?');">Vymazať</a></td>
										</tr>
										@endforeach	
  									</tbody>
								</table>
							</div>
							<div class="col-md-12 col-xs-12 text-center">
								{!! $users->render() !!}
							</div>
						</div>
					</div>
					@else
						<div class="panel-body">
							<div class="col-md-12 col-xs-12 scroll">
								@if (Session::has('error'))
                    				<div class="alert alert-danger"><h4>{{ Session::get('error') }}</h4></div>
                    			@endif
                    		</div>
                    	</div>
                    @endif
				</div>
				<div class="col-md-10 col-xs-12 col-md-offset-1">
					<div class="panel heading"><h4>Zoznam Manažérov</h4></div>
					<div class="panel-body">
						<div class="col-md-12 col-xs-12 scroll">
							<table class="table">
								<thead>
								<tr>			
									<th scope="col">Meno</th>
    								<th scope="col">Email</th> 
    								<th scope="col">Číslo</th> 
    							</tr>
    							</thead>
    							<tbody>
								@foreach($admins as $admin)
									<tr>
										<td>{{ $admin->name }}</td>
										<td>{{ $admin->email }}</td>
										<td>{{ $admin->phone }}</td>
										<td><a href="/admin/deleteadmin/{{$admin->id}}'" onclick="return confirm('Skutočne chcete tento záznam vymazať?');">Vymazať</a></td>
									</tr>
								</tbody>
								@endforeach
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

@endsection
