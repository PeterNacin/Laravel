@extends('layouts.admincalendar')

@section('content')

 	<div class="container">
    	<div class="panel panel-primary">
       		<div class="panel-heading"></div>
          	<div class="panel-body"> 
				<div class="row">	
					<div class="col-md-10 col-xs-12 col-md-offset-1">
						<div class="panel heading"></div>
						<div class="row">
							<div class="col-md-3 col-xs-4 ">
								Dátum: 
								<a href="/admin/movielist/?date=asc">Vzostupne</a> |
								<a href="/admin/movielist/?date=desc">Zostupne</a>
							</div>
							<div class="col-md-3 col-xs-4 ">
								Stav: 
								<a href="/admin/movielist/?active=0">Neaktívny</a> |
								<a href="/admin/movielist/?active=1">Aktívny</a> |
								<a href="/admin/movielist/?active=2">Novinky</a> |
								<a href="/admin/movielist/">Obnoviť</a>
							</div>
                    		<ul class="navbar-nav ml-auto">
								<div class="col-md-12 col-xs-12 ">
                        			        <form action="/admin/movielist/search" method="POST" role="search">
    											{{ csrf_field() }}
			    								<div class="input-group">
       												<input type="text" class="form-control" name="q"
            										placeholder="Vyhľadať názov filmu"> <span class="input-group-btn">
            										<button type="submit" class="btn btn-default">
                									<span class="glyphicon glyphicon-search"></span></button></span>
	    										</div>
											</form>
								</div>
							</ul>
						</div>
						<div class="panel-body">
							@if(isset($movies))
							<div class="col-md-12 col-xs-12 scroll">
								<table class="table">
  									<thead>
    								<h3>Filmy</h3>
									<tr>
										<th scope="col">Číslo</th>
										<th scope="col">Názov</th>
    									<th scope="col">Trvanie</th>
    									<th scope="col">Žáner</th>
    									<th scope="col">Stav</th>
    								</tr>
  									</thead>
 		 								<tbody>
 		 									@foreach($movies as $movie)

 		 									
										<tr>
											<td>{{ $movie->id }}</td>
											<td>{{ $movie->title }}</td>
											<td>{{ $movie->length }} min</td>
											<td>{{ $movie->genre }}</td>
											<td>@if($movie->active == '0') Neaktívny  @elseif($movie->active == '1') Aktívny @else Novinky @endif </td>

											@if($movie->active == '0')  
											<td><a href="{{ url('/admin/insertshow',$movie->id)}}"></a></td>
											@elseif($movie->active == '1') 
											<td><a href="{{ url('/admin/insertshow',$movie->id)}}">Pridať predstavenie </a></td>
											@else 
													@php $zhoda=0; $help=0; @endphp
													@foreach($yes as $ye)
														@if($movie->id == $ye->id)
															@php $zhoda++; $help = $ye->show_id;  @endphp
														@endif
														
													@endforeach
													@if($zhoda == 1)

													<td><a href="{{ url('/admin/showlist/?active=2')}}">Dátum premiéry už bol pridaný</a></td>
													@else


													<td><a href="{{ url('/admin/insertshow',$movie->id)}}">Pridať dátum premiéry</a></td>
													@endif

											@endif


											<td><a href="{{ url('/admin/editmovies',$movie->id)}}">Upraviť</a></td>
											<td><a href="/admin/deletemovie/{{$movie->id}}" onclick="return confirm('Skutočne chcete tento záznam vymazať?');">Vymazať</a></td>
										</tr>
									@endforeach
									</tbody>
								</table>
							</div>
							<div class="col-md-12 col-xs-12 text-center">
								{!! $movies->render() !!}
							</div>
							@else
							<div class="panel-body">
								<div class="col-md-12 col-xs-12 text-center scroll">
									@if (Session::has('error'))
                    					<div class="alert alert-danger"><h4>{{ Session::get('error') }}</h4></div>
                    				@endif
                    			</div>
                    		</div>
                    		@endif
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>




@endsection
