@extends('layouts.admincalendar')

@section('content')

 	<div class="container">
    	<div class="panel panel-primary">
       		<div class="panel-heading"></div>
          	<div class="panel-body"> 
				<div class="row">	
					<div class="col-md-12 col-xs-12">
						<div class="panel heading"></div>
						<div class="panel-body">
							@if (Session::has('success'))
                    			<div class="alert alert-success"><h4>{{ Session::get('success') }}</h4></div>
                    		@endif
							@if(isset($reservations))
							<div class="col-md-12 col-xs-12 scroll">
								<table class="table">
  									<thead>
  										<h3>Rezervácie</h3>
										<tr>
											<th scope="col">Číslo</th>
											<th scope="col">Email</th>
    										<th scope="col">Rada</th>
    										<th scope="col">Sedadlo</th>
    										<th scope="col">Názov filmu</th>
    										<th scope="col">Dátum</th>
    										<th scope="col">Čas</th>
    										<th scope="col">Sála</th>
    										<th scope="col">Rezervované v čase</th>
    									</tr>
  									</thead>
  									<tbody>
  									@foreach($reservations as $reservation)
										<tr>
											<td>{{ $reservation->id }}</td>
											<td>{{ $reservation->email }}</td>
											<td>{{ $reservation->row }}</td>
											<td>{{ $reservation->seat }}</td>
											<td>{{ $reservation->title}}</td>
											<td>{{ $reservation->date}}</td>
											<td>{{ $reservation->time}}</td>
											<td><a href="{{ url('/film',$reservation->show_id)}}"><strong>{{ $reservation->hall }}</strong></a></td>
											<td>{{ $reservation->created_at }}</td>
										</tr>
									<tr>
									@endforeach
									</tr>
									</tbody>
								</table>
							</div>
							<div class="col-md-12 col-xs-12 col-md-offset-5 col-xs-offset-5">
								@if($reservation->expired == '0')<td><a href="/admin/confirmreservation/{{$reservation->id}}" class="btn btn-primary mb-2" onclick="return confirm('Skutočne chcete tento záznam potvrdiť?');">Potvrdiť</a></td>@endif
							</div>
                    		@endif
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>




@endsection
