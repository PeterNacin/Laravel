@extends('layouts.admincalendar')

@section('content')

<div class="container">
  <div class="panel panel-primary">
    <div class="panel-heading"></div>
    <div class="panel-body"> 
      <div class="row">
        <div class="col-md-4 col-xs-10 col-md-offset-1 col-xs-offset-1">
          <div class="panel heading"><h4>Úprava filmu</h4></div>
            <div class="row">  
							<form method="POST" id="withText" action="{{ url('/admin/updateshow')}}">
								{{csrf_field()}}
								<input type="hidden" name="id" value="{{ $id }}">
                <table>
                  <tr>
                    <td><strong>Titul</strong></td>
                    <td><input type="text" class="form-control mb-2 mr-sm-2" name="title" value="{{$shows->title}}" readonly></td>
                  </tr>
                  <tr>
                    <td><strong>Deň</strong></td>
                    <td>
                      <input type="date" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="date" value="{{$shows->date}}" />  
                    </td>
                  </tr>
                  @if($shows->active == '1')
                  <tr>
                    <td><strong>Čas</strong></td>
                    <td>
                      <input type="time" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="time" value="{{$shows->time}}" /> 
                    </td>
                  </tr>

                  
                  @else 
                  <input type="hidden" name="time" value="new">
                  @endif
                  <tr>
                    <td><input type="submit" class="btn btn-primary mb-2" name="Submit" value="Zmeniť"></td>
                  </tr>
                </table> 
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

@endsection