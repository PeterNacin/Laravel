@extends('layouts.admincalendar')

@section('style')
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.0/fullcalendar.min.css"/>
@endsection
 
@section('content')
  <div class="container">
    <div class="panel panel-primary">
      <div class="panel-heading"></div>
      <div class="panel-body"> 
        {!! Form::open(array('route' => 'admin.events.add','method'=>'POST','files'=>'true')) !!}
          <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
              @if (Session::has('success'))
                <div class="alert alert-success">{{ Session::get('success') }}</div>
              @elseif (Session::has('warnning'))
                <div class="alert alert-danger">{{ Session::get('warnning') }}</div>
              @endif
            </div>
            <div class="col-xs-10 col-sm-6 col-md-3">
              <div class="form-group">
                {!! Form::label('event_name','Zamestnanec:') !!}
                <div class="">
                  <label class="sr-only" for="inlineFormInputName2">Name</label>
                  <select class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="event_name">
                    @foreach($users as $user)<option value="<?php echo $user->name; ?>">{{$user->name}}</option>@endforeach
                  </select>
                  {!! $errors->first('event_name', '<p class="alert alert-danger">:message</p>') !!}
                </div>
              </div>
            </div>
            <div class="col-xs-10 col-sm-6 col-md-2">
              <div class="form-group">
                {!! Form::label('event_name','Pozícia:') !!}
                <div class="">
                  <label class="sr-only">Name</label>
                  <select class="form-control mb-2 mr-sm-2" name="position">
                    <option class="red" value="otvárač">Otvárač</option>
                    <option class="orange" value="zatvárač">Zatvárač</option>
                    <option class="violet" value="výpomoc floor">Floor výpomoc</option>
                    <option class="yellow" value="pokladňa">Pokladňa</option>
                    <option class="green" value="buffet">Buffet</option>
                    <option class="light-green" value="výpomoc buffet">Buffet výpomoc</option>
                  </select>
                  {!! $errors->first('event_name', '<p class="alert alert-danger">:message</p>') !!}
                </div>
              </div>
            </div>
            <div class="col-xs-10 col-sm-6 col-md-2">
              <div class="form-group">
                {!! Form::label('start_date','Deň:') !!}
                <div class="">
                  <input type="date" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="start_date" value="<?php echo date('Y-m-d'); ?>" /> 
                      {!! $errors->first('start_date', '<p class="alert alert-danger">:message</p>') !!}
                </div>
              </div>
            </div>
            <div class="col-xs-10 col-sm-6 col-md-2">
              <div class="form-group">
                {!! Form::label('start_date','Čas:') !!}
                <div class="">
                  <input type="time" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="start_time" value="<?php echo date('H:i'); ?>" />   <input type="time" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="end_time" value="<?php echo date('H:i'); ?>" />  
                      {!! $errors->first('start_date', '<p class="alert alert-danger">:message</p>') !!}
                </div>
              </div>
            </div>
            <div class="col-xs-3 col-sm-3 col-md-1 text-center"> &nbsp;<br/>
              <div class="form-group">
              <button type="submit" class="btn btn-primary mb-2 botbot">Pridať</button>
            </div>
            </div>
          </div>
        {!! Form::close() !!}
      </div>
    </div>
    <div class="text-center">
      <a href="/admin/events/?confirm=1">Nahlásený</a> |
      <a href="/admin/events/?confirm=0">Nenáhlasený</a> ---
      <a href="/admin/events/">Obnoviť</a>
    </div>
    <div class="row">
      <div class="text-center center-block">
        <div class="foo red"><strong>O</strong></div>
        <div class="foo orange"><strong>Z</strong></div>
        <div class="foo violet"><strong>Fv</strong></div>
        <div class="foo yellow"><strong>P</strong></div>
        <div class="foo green "><strong>B</strong></div>
        <div class="foo light-green "><strong>Bv</strong></div>      
      </div>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2">
          <div class="panel panel-default">
            <div class="panel-heading"></div>
            <div class="panel-body">
              {!! $calendar_details->calendar() !!}
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>  
@endsection

@section('script')
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.0/fullcalendar.min.js"></script>

{!! $calendar_details->script() !!}

@endsection

