@extends('layouts.admincalendar')

@section('content')

 	<div class="container">
    	<div class="panel panel-primary">
       		<div class="panel-heading"></div>
          	<div class="panel-body"> 
				<div class="row">	
					<div class="col-md-10 col-xs-12 col-md-offset-1">
						<div class="panel heading"></div>
						<div class="row">
                    		<ul class="navbar-nav ml-auto ">
								<div class="col-md-12 col-xs-12 ">
                        			        <form action="/admin/showlist/search" method="POST" role="search">
    											{{ csrf_field() }}
			    								<div class="input-group">
       												<input type="text" class="form-control" name="q"
            										placeholder="Vyhľadať názov filmu"> <span class="input-group-btn">
            										<button type="submit" class="btn btn-default">
                									<span class="glyphicon glyphicon-search"></span></button></span>
	    										</div>
											</form>

                                			<form action="/admin/showlist/search" method="POST" role="search">
		    									{{ csrf_field() }}
			    								<div class="input-group">
        											<input type="date" class="form-control" name="q"
            										placeholder="Vyhľadať dátum filmu"> <span class="input-group-btn">
            										<button type="submit" class="btn btn-default">
                									<span class="glyphicon glyphicon-search"></span></button></span>
    											</div>
											</form>
								</div>
							</ul>
						</div>
						<div class="panel-body">
							@if(isset($shows))
							<div class="col-md-12 col-xs-12 scroll">
								<table class="table">
  									<thead>
    								<h3>Premietanie filmov</h3>
									<tr>
										<th scope="col">Číslo</th>
										<th scope="col">Názov</th>
    									<th scope="col">Dátum</th>
    									<th scope="col">Čas</th>
    								</tr>
  									</thead>
 		 								<tbody>
 		 									@foreach($shows as $show)
										<tr>
											<td>{{ $show->title }}</td>
											<td>{{ $show->date }}</td>
											<td>{{ $show->time }}</td>
											<td><a href="{{ url('/admin/editshow',$show->id)}}">Upraviť</a></td>
											<td><a href="/admin/deleteshow/{{$show->id}}" onclick="return confirm('Skutočne chcete tento záznam vymazať?');">Vymazať</a></td>
										</tr>
									@endforeach
									</tbody>
								</table>
							</div>
							<div class="col-md-12 col-xs-12 text-center">
								{!! $shows->render() !!}
							</div>
							@else
							<div class="panel-body">
								<div class="col-md-12 col-xs-12 text-center scroll">
									@if (Session::has('error'))
                    					<div class="alert alert-danger"><h4>{{ Session::get('error') }}</h4></div>
                    				@endif
                    			</div>
                    		</div>
                    		@endif
						</div>
						<div class="panel-body">
							@if(isset($future_shows))
							<div class="col-md-12 col-xs-12 scroll">
								<table class="table">
  									<thead>
    								<h3>Premiéry</h3>
									<tr>
										<th scope="col">Číslo</th>
										<th scope="col">Názov</th>
    									<th scope="col">Dátum</th>
    								</tr>
  									</thead>
 		 								<tbody>
 		 									@foreach($future_shows as $future_show)
										<tr>
											<td>{{ $future_show->title }}</td>
											<td>{{ $future_show->date }}</td>
											<td><a href="{{ url('/admin/editshow',$future_show->id)}}">Upraviť</a></td>
											<td><a href="/admin/deleteshow/{{$future_show->id}}" onclick="return confirm('Skutočne chcete tento záznam vymazať?');">Vymazať</a></td>
										</tr>
									@endforeach
									</tbody>
								</table>
							</div>
							<div class="col-md-12 col-xs-12 text-center">
								{!! $future_shows->render() !!}
							</div>
							@else
							<div class="panel-body">
								<div class="col-md-12 col-xs-12 text-center scroll">
									@if (Session::has('error'))
                    					<div class="alert alert-danger"><h4>{{ Session::get('error') }}</h4></div>
                    				@endif
                    			</div>
                    		</div>
                    		@endif
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>




@endsection

