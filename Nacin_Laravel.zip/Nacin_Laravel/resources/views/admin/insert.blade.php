@extends('layouts.admincalendar')

@section('content')

   <div class="container">
    	<div class="panel panel-primary">
       		<div class="panel-heading"></div>
          	<div class="panel-body"> 
				<div class="row">
					<div class="col-md-4 col-xs-10 col-md-offset-1 col-xs-offset-1">
						<div class="panel heading"><h4>Pridať zamestnanca</h4></div>
						<div class="row">
							<form method="POST" action="/admin/insert">
								<table>
									<tr>
										{{csrf_field()}}
										<td><strong>Meno: </strong></td>
										<td><input type="text" class="form-control mb-2 mr-sm-2" name="name" required></td>
									</tr>
									<tr>
										<td><strong>Email: </strong></td>
										<td><input type="text" class="form-control mb-2 mr-sm-2" name="email" required></td>
									</tr>
									<tr>
										<td><strong>Heslo: </strong></td>
										<td><input id="password" type="password" minlength="6" class="form-control mb-2 mr-sm-2" name="password" required></td>
									</tr>
									<tr>
										<td><strong>Číslo: </strong></td>
										<td><input type="text" name="phone" class="form-control mb-2 mr-sm-2" required></td>
									</tr>
									<tr>
										<td><strong>Floor: </strong></td>
										<td>
											<select name="floor" class="form-control mb-2 mr-sm-2" value="1">
												<option value="1">Robí</option>
												<option value="0">Nerobí</option>
											</select>
										</td>
									</tr>
									<tr>
										<td><strong>Buffet: </strong></td>
										<td>
											<select name="buffet" class="form-control mb-2 mr-sm-2" value="0">
												<option value="1">Robí</option>
												<option value="0" selected>Nerobí</option>
											</select>
										</td>
									</tr>
									<tr>
										<td><strong>Pokladňa: </strong></td>
										<td>
											<select name="pokladna" class="form-control mb-2 mr-sm-2" value="0">
												<option value="1">Robí</option>
												<option value="0" selected>Nerobí</option>
											</select>
										</td>
									</tr>
									<tr>
										<td><input type="submit" class="btn btn-primary mb-2" name="sumbit" value="Pridať"></td>
									</tr>
								</table>
							</form>
							<br>
						</div>
					</div>
					<div class="col-md-4 col-xs-10 col-md-offset-1 col-xs-offset-1">
						<div class="panel heading"><h4>Pridať Manažéra</h4></div>
						<div class="row">
							<form method="POST" action="/admin/insertadmin">
								<table>
									<tr>
										{{csrf_field()}}
										<td><strong>Meno: </strong></td>
										<td><input type="text" class="form-control mb-2 mr-sm-2" name="name" required></td>
									</tr>
									<tr>
										<td><strong>Email: </strong></td>
										<td><input type="text" class="form-control mb-2 mr-sm-2" name="email" required></td>
									</tr>
									<tr>
										<td><strong>Heslo: </strong></td>
										<td><input id="password" minlength="6" class="form-control mb-2 mr-sm-2" type="password" name="password" required></td>
									</tr>
									<tr>
										<td><strong>Číslo: </strong></td>
										<td><input type="text" class="form-control mb-2 mr-sm-2" name="phone" required></td>
									</tr>
									<tr>
										<td><input type="submit" class="btn btn-primary mb-2" name="sumbit" value="Pridať"></td>
									</tr>
								</table>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	
@endsection