@extends('layouts.admincalendar')

@section('content')

 	<div class="container">
    	<div class="panel panel-primary">
       		<div class="panel-heading"></div>
          	<div class="panel-body"> 
				<div class="row">	
					<div class="col-md-10 col-md-offset-1">
						<div class="panel heading"></div>
						<div class="row">
                    		<ul class="navbar-nav ml-auto">
								<div class="col-md-12 col-xs-12">
									
                        			        <form action="/admin/reservationlist/search" method="POST" role="search">
    											{{ csrf_field() }}
			    								<div class="input-group">
       												<input type="text" class="form-control" name="q"
            										placeholder="Číslo/Email"> <span class="input-group-btn">
            										<button type="submit" class="btn btn-default">
                									<span class="glyphicon glyphicon-search"></span></button></span>
	    										</div>
											</form>
                                			<form action="/admin/reservationlist/search" method="POST" role="search">
		    									{{ csrf_field() }}
			    								<div class="input-group">
        											<input type="date" class="form-control" name="q"
            										placeholder="Vyhľadať dátum rezervácie"> <span class="input-group-btn">
            										<button type="submit" class="btn btn-default">
                									<span class="glyphicon glyphicon-search"></span></button></span>
    											</div>
											</form>
                            			
								</div>
							</ul>
						</div>
						<div class="panel-body">
							@if (Session::has('success'))
                    			<div class="alert alert-success"><h4>{{ Session::get('success') }}</h4></div>
                    		@endif
							@if(isset($reservations))
							<div class="col-md-12 col-xs-12 scroll">
								<table class="table">
  									<thead>
  										<h3>Rezervácie</h3>
										<tr>
											<th scope="col">Číslo</th>
											<th scope="col">Email</th>
											<th scope="col">Vypršaná rezervácie</th>
    										<th scope="col">Rezervované v čase</th>
    									</tr>
  									</thead>
  									<tbody>
  									@foreach($reservations as $reservation)
										<tr>
											<td>{{ $reservation->id }}</td>
											<td>{{ $reservation->email }}</td>
											<td>@if($reservation->expired == '1') Áno  @else Nie @endif </td>
											<td>{{ $reservation->created_at }}</td>	
											<td><a href="{{ url('/admin/showreservation',$reservation->id)}}">Zobraziť</a></td>
										</tr>
									@endforeach
									</tbody>
								</table>
							</div>
							<div class="col-md-12 col-xs-12 text-center">
								{!! $reservations->render() !!}
							</div>
							@else
							<div class="panel-body">
								<div class="col-md-12 col-xs-12 text-center">
									@if (Session::has('error'))
                    					<div class="alert alert-danger"><h4>{{ Session::get('error') }}</h4></div>
                    				@endif
                    			</div>
                    		</div>
                    		@endif
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>




@endsection
