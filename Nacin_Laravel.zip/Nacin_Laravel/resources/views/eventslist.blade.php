@extends('layouts.calendar')

@section('content')

	<div class="container">
    	<div class="panel panel-primary">
       		<div class="panel-heading"></div>
          	<div class="panel-body"> 
				<div class="row">
					<div class="col-md-10 col-md-offset-1">
						<div class="panel heading"><h4>Moje smeny</h4></div>
						<div class="row">
							<div class="col-md-6">
								Dátum: 
								<a href="/eventslist?event_time=asc">Vzostupne</a> |
								<a href="/eventslist?event_time=desc">Zostupne</a> |
								<a href="/eventslist/">Obnoviť</a>
							</div>
						</div>
						<div class="panel-body">
							<div class="col-md-8 col-xs-12">
								<table class="table">
  									<thead>
    									<h3>Smeny na ktoré sa hlásim</h3>
										<tr>
											<th scope="col">Zamestnanec</th>
    										<th scope="col">Deň</th> 
    									</tr>
    								</thead>
    								<tbody>
    								@foreach($events_A as $event)
										<tr>
										<?php $conc = Auth::user()->name .' ---'; ?>
										@if(strpos($event->event_name,$conc) !== false) 
											<td>{{ $event->event_name }}</td>
											<td>{{date("d.m.Y", strtotime($event->start_date))}}</td>
											<td><a href="{{ url('/editevents',$event->id)}}">Upraviť</a></td>
											<td><a href="/deleteevents/{{$event->id}}'" onclick="return confirm('Skutočne chcete tento záznam vymazať?');">Vymazať</a></td>
							 			@endif
										</tr>
									@endforeach
									</tbody>
								</table>
							</div>
							<div class="col-md-8 col-xs-12 text-center">
								{!! $events_A->render() !!}
							</div>
						</div>
					</div>
					<div class="col-md-8 col-xs-12 col-md-offset-1">
						<div class="panel heading"></div>
						<div class="panel-body">
							<div class="col-md-8 col-xs-12">
								<table class="table">
  									<thead>
    									<h3>Som nahlásený/á na</h3>
										<tr>
											<th scope="col">Zamestnanec</th>
    										<th scope="col">Deň</th> 
    									</tr>
    								</thead>
    								<tbody>
    								@foreach($events_B as $event)
										<tr>
										<?php $conc = Auth::user()->name .' ==>'; ?>
										@if(strpos($event->event_name,$conc) !== false) 
											<td>{{ $event->event_name }}</td>
											<td>{{date("d.m.Y", strtotime($event->start_date))}}</td>
							 			@endif
										</tr>
									@endforeach
									</tbody>
								</table>
							</div>
							<div class="col-md-8 col-xs-12 text-center">
								{!! $events_B->render() !!}
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

@endsection
