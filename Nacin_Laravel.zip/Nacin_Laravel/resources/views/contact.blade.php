@extends('layouts.calendar')

@section('content')

 	<div class="container">
    	<div class="panel panel-primary">
       		<div class="panel-heading"></div>
          	<div class="panel-body"> 
				<div class="row">		
					<div class="col-md-10 col-md-offset-1">
						<div class="panel heading"><h4>Zoznam Manažérov</h4></div>
						<div class="panel-body">
							<div class="col-md-7">
							<table style="width:100%">
								<tr>
									<th>Meno</th>
    								<th>Email</th> 
    								<th>Číslo</th> 
    							</tr>
								@foreach($admins as $admin)
									<tr>
										<td>{{ $admin->name }}</td>
										<td>{{ $admin->email }}</td>
										<td>{{ $admin->phone }}</td>
									</tr>
								@endforeach
									<tr>
										<td>Cinemax Trenčín</td>
										<td>cinemax@mail.com></td>
										<td>123456789</td>
									</tr>
							</table>
						</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


@endsection
