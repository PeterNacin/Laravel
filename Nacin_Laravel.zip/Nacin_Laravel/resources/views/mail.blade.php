<div>
	<strong>{{ $data[0]}}</strong> <br>
    Film : {{ $data[1]}} <br>
    Deň : {{ $data[2] }} <br>
    Čas : {{ $data[3] }} <br>
    Sála : {{ $data[4] }} <br>
    Sedadlá : {{ $data[5] }} <br>
</div>