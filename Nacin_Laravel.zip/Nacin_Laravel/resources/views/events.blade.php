@extends('layouts.calendar')

@section('style')
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.0/fullcalendar.min.css"/>
@endsection
 
@section('content')
  <div class="container">
    <div class="panel panel-primary">
      <div class="panel-heading"></div>
      <div class="panel-body">    
        {!! Form::open(array('route' => 'events.add','method'=>'POST','files'=>'true')) !!}
          <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
              @if (Session::has('success'))
                <div class="alert alert-success">{{ Session::get('success') }}</div>
              @elseif (Session::has('warnning'))
                <div class="alert alert-danger">{{ Session::get('warnning') }}</div>
              @endif
            </div>
            <div class="col-xs-10 col-sm-6 col-md-3">
              <div class="form-group">
                {!! Form::label('event_name','Pozícia:') !!}
                <div class="">
                  <label class="sr-only" for="inlineFormInputName2">Name</label>
                  <select class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="event_name">
                    <option value="otvárač">Otvárač</option>
                    <option value="zatvárač">Zatvárač</option>
                    <option value="buffet">Buffet</option>
                    <option value="výpomoc floor">Výpomoc floor</option>
                    <option value="výpomoc buffet">Výpomoc buffet</option>
                    <option value="pokladňa">Pokladňa</option>
                  </select>
                  {!! $errors->first('event_name', '<p class="alert alert-danger">:message</p>') !!}
                </div>
              </div>
            </div>
            <div class="col-xs-10 col-sm-6 col-md-3">
              <div class="form-group">
                {!! Form::label('start_date','Deň:') !!}
                <div class="">
                  <input type="date" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="start_date" value="<?php echo date('Y-m-d'); ?>">
                  {!! $errors->first('start_date', '<p class="alert alert-danger">:message</p>') !!}
                </div>
              </div>
            </div>
              <div class="col-xs-3 col-sm-3 col-md-1 text-center"> &nbsp;<br/>
                <button type="submit" class="btn btn-primary mb-2 botbot">Pridať</button>
              </div>
            </div>
          {!! Form::close() !!}
        </div>
      </div>
    </div>
    <div class="text-center">
      <a href="/events/?my=1">Moje smeny</a> ---
      <a href="/events/">Obnoviť</a>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2">
          <div class="panel panel-default">
            <div class="panel-heading"></div>
			      <div class="panel-body">
              {!! $calendar_details->calendar() !!}
            </div>
          </div>
         </div>
       </div>
    </div>
  </div>

@endsection

@section('script')
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.0/fullcalendar.min.js"></script>
{!! $calendar_details->script() !!}


@endsection

