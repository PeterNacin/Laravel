  @extends('layouts.app')

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <!------ Include the above in your HEAD tag ---------->

  <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css" rel="stylesheet">

  @section('style')
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.css"/>
  @endsection

  
  @section('content')
  <div class="container">
  	<div class="panel panel-primary">
    	<div class="panel-heading"></div>
    	<div class="panel-body"> 
     		<div class="row justify-content-center">
        	<div class="col-md-6 col-xs-8 col-md-offset-1">
          	<div class="panel heading login-top-margin"><h4></h4></div>
           	<div class="row">  
						  <form method="POST" action="{{ url('/ticket')}}">
							  {{csrf_field()}}
							  <input type="hidden" name="id" value="{{ $id }}">
                <input type="hidden" name="NumberDisplay" value="{{$number}}">
						    <table>
                  @if($errors->any())
                    <tr>
                      <div class="alert alert-danger">{{$errors->first()}}</div>
                    <tr>
                  @endif
                  <tr>
                    <td><strong>Emailová adresa</strong></td>
                    <td><input type="text" class="form-control mb-2 mr-sm-2" name="nameDisplay" id="nameDisplay" value="{{$name}}"></td>
                  </tr>
                  @foreach($movies as $movie)
                    <tr>
                      <td><strong>Názov</strong></td>
                      <td><input type="text" class="form-control mb-2 mr-sm-2" value="{{$movie->title}}" readonly></td>
                    </tr>
                    <tr>
                      <td><strong>Dátum</strong></td>
                      <td><input type="text" class="form-control mb-2 mr-sm-2" value="{{$movie->date}}" readonly></td>
                    </tr>
                    <tr>
                      <td><strong>Čas</strong></td>
                      <td><input type="text" class="form-control mb-2 mr-sm-2" value="{{$movie->time}}" readonly></td>
                    </tr>
                    <tr>
                      <td><strong>Sála</strong></td>
                      <td><input type="text" class="form-control mb-2 mr-sm-2" value="{{$movie->hall}}" readonly></td>
                    </tr>
						      @endforeach
								  <tr>
							      <td><strong>Miesta</strong></td>
							      <td><input type="text" class="form-control mb-2 mr-sm-2" name="seatsDisplay" id="seatsDisplay" value="{{$numSeats}}" readonly></td>
						      </tr>
						      <tr>
									  <td><input type="submit" class="btn btn-primary mb-2" name="Submit" value="Rezervovať"></td>
								  </tr>
							  </table>
						  </form>
  					</div>
	   			</div>
	 	   	</div>
  	 	</div>
	  </div>
  </div>

 @endsection