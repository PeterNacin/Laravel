<?php $__env->startSection('content'); ?>

 	<div class="container">
    	<div class="panel panel-primary">
       		<div class="panel-heading"></div>
          	<div class="panel-body"> 
				<div class="row">	
					<div class="col-md-10 col-xs-12 col-md-offset-1">
						<div class="panel heading"></div>
						<div class="row">
							<div class="col-md-3 col-xs-4 ">
								Dátum: 
								<a href="/admin/showlist/?date=asc">Vzostupne</a> |
								<a href="/admin/showlist/?date=desc">Zostupne</a>
							</div>
							<div class="col-md-3 col-xs-4 ">
								Stav: 
								<a href="/admin/showlist/?active=1">Premietaný</a> |
								<a href="/admin/showlist/?active=2">Novinky</a> |
								<a href="/admin/showlist/">Obnoviť</a>
							</div>

                    		<ul class="navbar-nav ml-auto ">
								<div class="col-md-12 col-xs-12 ">
                        			        <form action="/admin/showlist/search" method="POST" role="search">
    											<?php echo e(csrf_field()); ?>

			    								<div class="input-group">
       												<input type="text" class="form-control" name="q"
            										placeholder="Vyhľadať názov filmu"> <span class="input-group-btn">
            										<button type="submit" class="btn btn-default">
                									<span class="glyphicon glyphicon-search"></span></button></span>
	    										</div>
											</form>

                                			<form action="/admin/showlist/search" method="POST" role="search">
		    									<?php echo e(csrf_field()); ?>

			    								<div class="input-group">
        											<input type="date" class="form-control" name="q"
            										placeholder="Vyhľadať dátum filmu"> <span class="input-group-btn">
            										<button type="submit" class="btn btn-default">
                									<span class="glyphicon glyphicon-search"></span></button></span>
    											</div>
											</form>
								</div>
							</ul>
						</div>
						<div class="panel-body">
							<?php if(isset($shows)): ?>
							<div class="col-md-12 col-xs-12 scroll">
								<table class="table">
  									<thead>
    								<h3>Premietanie filmov</h3>
									<tr>
										<th scope="col">Číslo</th>
										<th scope="col">Názov</th>
    									<th scope="col">Dátum</th>
    									<th scope="col">Čas</th>
    								</tr>
  									</thead>
 		 								<tbody>
 		 									<?php $__currentLoopData = $shows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $show): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e($show->id); ?></td>
											<td><?php echo e($show->title); ?></td>
											<td><?php echo e($show->date); ?></td>

											<?php if($show->time == '00:00:00'): ?>
											<td> Premiéra </td>
											<?php else: ?>
											<td><?php echo e($show->time); ?></td>
											<?php endif; ?>


											<td><a href="<?php echo e(url('/admin/editshow',$show->id)); ?>">Upraviť</a></td>
											<td><a href="/admin/deleteshow/<?php echo e($show->id); ?>" onclick="return confirm('Skutočne chcete tento záznam vymazať?');">Vymazať</a></td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
							<div class="col-md-12 col-xs-12 text-center">
								<?php echo $shows->render(); ?>

							</div>
							<?php else: ?>
							<div class="panel-body">
								<div class="col-md-12 col-xs-12 text-center scroll">
									<?php if(Session::has('error')): ?>
                    					<div class="alert alert-danger"><h4><?php echo e(Session::get('error')); ?></h4></div>
                    				<?php endif; ?>
                    			</div>
                    		</div>
                    		<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admincalendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>