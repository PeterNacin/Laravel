<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>jQuery UI Datepicker - Default functionality</title>
  <script type="text/javascript" src="/bower_components/jquery/jquery.min.js"></script>
  <script type="text/javascript" src="/bower_components/moment/min/moment.min.js"></script>
  <script type="text/javascript" src="/bower_components/bootstrap/dist/js/bootstrap.min.js"></script>
  <script type="text/javascript" src="/bower_components/eonasdan-bootstrap-datetimepicker/build/js/bootstrap-datetimepicker.min.js"></script>
  <link rel="stylesheet" href="/bower_components/bootstrap/dist/css/bootstrap.min.css" />
  <link rel="stylesheet" href="/bower_components/eonasdan-bootstrap-datetimepicker/build/css/bootstrap-datetimepicker.min.css" />
<div style="overflow:hidden;">
    <div class="form-group">
        <div class="row">
            <div class="col-md-8">
                <div id="datetimepicker12"></div>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        $(function () {
            $('#datetimepicker12').datetimepicker({
                inline: true,
                sideBySide: true
            });
        });
    </script>
</div>
</head>
<body>
 
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <h3 style="color: #fff;">HOW to filter records</h3>
  </div>
</nav>
<div class="container">
  <h3 style="text-align: center;font-weight: bold">PHP filter</h3>
  <div class="row">
    <form class="form-horizontal" action="<?php echo e(url('/admin/randomsub')); ?>" method=POST>
      <?php echo e(csrf_field()); ?>

      <div class="form-group">
        <label class="col-lg-2 control-label">From</label>
        <div class="col-lg-4">
          <input type="text" class="form-control" name="event_time" id="from">
        </div>
      </div>
      <div class="form-group">
        <label class="col-lg-2 control-label"></label>
        <div class="col-lg-4">
          <input type="submit" class="btn btn-primary" name="submit">
        </div>
      </div>
    </form>
  </div>
  <div class="container">
      <div class="panel panel-primary">
          <div class="panel-heading"></div>
            <div class="panel-body"> 
        <div class="row">
          <div class="col-md-10 col-md-offset-1">
            <div class="panel heading"><h4>Zoznam smien</h4></div>
            <div class="panel-body">
              <div class="col-md-5">
                <table style="width:100%">
                  <h3>Hlási sa</h3>
                  <tr>
                    <th>Zamestnanec</th>
                      <th>Deň</th> 
                    </tr>
                  <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <?php if(strpos($event->event_name, ' --- ') !== false): ?> 
                      <td><?php echo e($event->event_name); ?></td>
                      <td><?php echo e(date("d-m-Y", strtotime($event->start_date))); ?></td>
                      <td><a href="/admin/deleteevents/<?php echo e($event->id); ?>'" onclick="return confirm('Skutočne chcete tento záznam vymazať?');">Vymazať</a></td>
                    <?php endif; ?>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              </div>
            </div>
          </div>
          <div class="col-md-10 col-md-offset-1">
            <div class="panel heading"></div>
            <div class="panel-body">
              <div class="col-md-8">
                <table style="width:100%">
                  <h3>Nahlásený</h3>
                  <tr>
                    <th>Zamestnanec</th>
                      <th>Príchod</th> 
                      <th>Odchod</th>
                    </tr>
                  <?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <?php if(strpos($event->event_name, ' ==> ') !== false): ?>
                        <td><?php echo e($event->event_name); ?></td>
                        <td><?php echo e(date("d-m-Y H:i", strtotime($event->start_date))); ?></td>
                        <td><?php echo e(date("d-m-Y H:i", strtotime($event->end_date))); ?></td>
                        <td><a href="<?php echo e(url('/admin/editevents',$event->id)); ?>">Upraviť</a></td>
                        <td><a href="/admin/deleteevents/<?php echo e($event->id); ?>'" onclick="return confirm('Skutočne chcete tento záznam vymazať?');">Vymazať</a></td>
                      <?php endif; ?>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>


</body>
</html>
