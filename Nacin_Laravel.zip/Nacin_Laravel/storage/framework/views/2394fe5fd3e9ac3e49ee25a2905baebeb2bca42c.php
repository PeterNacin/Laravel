<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.css"/>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
        <div class="container">
 
            <div class="panel panel-primary">
 
             <div class="panel-heading">Event Calendar in Laravel 5 Using Laravel-fullcalendar</div>
 
              <div class="panel-body">    

 
                   <?php echo Form::open(array('route' => 'events.add','method'=>'POST','files'=>'true')); ?>

                    <div class="row">
                       <div class="col-xs-12 col-sm-12 col-md-12">
                          <?php if(Session::has('success')): ?>
                             <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
                          <?php elseif(Session::has('warnning')): ?>
                              <div class="alert alert-danger"><?php echo e(Session::get('warnning')); ?></div>
                          <?php endif; ?>
 
                      </div>
 
                      <div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="form-group">
                            <?php echo Form::label('event_name','Event Name:'); ?>

                            <div class="">
                              <label class="sr-only" for="inlineFormInputName2">Name</label>
                                <select class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="event_name">
                                  <option value="otvarac">floor</option>
                                  <option value="buffet">buffet</option>
                                  <option value="pokladna">pokladna</option>
                                  <option value="vypomoc">vypomoc</option>
                                </select>
                              <?php echo $errors->first('event_name', '<p class="alert alert-danger">:message</p>'); ?>

                            </div>
                        </div>
                      </div>


 
                      <div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="form-group">
                          <?php echo Form::label('start_date','Start_Date:'); ?>

                          <div class="">
                          <input type="datetime-local" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" placeholder="Jane Doe" name="start_date" value="2000-01-01T10:00">

                          <?php echo $errors->first('start_date', '<p class="alert alert-danger">:message</p>'); ?>

                          </div>
                        </div>
                      </div>

                      <div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="form-group">
                          <?php echo Form::label('end_date','End_Date:'); ?>

                          <div class="">
                          <input type="datetime-local" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" placeholder="Jane Doe" name="end_date" value="2000-01-01T13:00">


                          <?php echo $errors->first('end_date', '<p class="alert alert-danger">:message</p>'); ?>

                          </div>
                        </div>
                      </div>

                      <div class="col-xs-1 col-sm-1 col-md-1 text-center"> &nbsp;<br/>
                      <button type="submit" class="btn btn-primary mb-2">Pridat</button>
                      </div>
                    </div>
                   <?php echo Form::close(); ?>

 
             </div>
 
            </div>
 
            <div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Full Calendar Example</div>
                    <div class="panel-body">
                   <?php echo $calendar_details->calendar(); ?>

                </div>
            </div>
        </div>
    </div>
</div>
 
        </div>
        
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.js"></script>
<?php echo $calendar_details->calendar(); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admincalendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>