<!DOCTYPE html>
<html>

<head>
    <title>Laravel</title>
    <!-- Meta-Tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta charset="iso-8859-1">

    <!-- //Meta-Tags -->
    <!-- Index-Page-CSS -->
     <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/movie.css')); ?>" rel="stylesheet"> 
    <!-- //Custom-Stylesheet-Links -->
    <!--fonts -->
    <script src='//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script><script src="//m.servedby-buysellads.com/monetization.js" type="text/javascript"></script></body>    
    
    <!-- //fonts -->
</head>

    <body class="app-background-color" onload="onLoaderFunc()">
        <a href="<?php echo e(url('/movies')); ?>">
            <img border="0" alt="back-button" src="/images/back-button.png" class="back-button-image">
        </a>
        
        <h1 class="text-center top-margin-header">Výber sedadiel</h1>


        <div class="container">
            <div class="film-body">
                <div class="inputForm">
                    <?php if(Session::has('success')): ?>
                    <div class="alert alert-success"><h4><?php echo e(Session::get('success')); ?></h4></div>
                    <?php endif; ?>
                    <?php if(Session::has('error')): ?>
                    <div class="alert alert-danger"><h4><?php echo e(Session::get('error')); ?></h4></div>
                    <?php endif; ?>
                    <div class="inputInfo">
                        <div class="info-left">
                            <label> Emailová adresa
                                <span>*</span>
                            </label>
                            <input type="text" id="Username" required>
                        </div>
                        <div class="info-right">
                            <label> Počet sedadiel
                                <span>*</span>
                            </label>
                            <input type="number" id="Numseats" required min="1" max="6">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="d-flex justify-content-center">
                            <p id="notification"></p>
                            <button id="confirm-btn" onclick="takeData()">Začať výber</button>
                            <div class="form-group">
                                <div class="d-flex justify-content-center">
                                    <form method="post" id="withButton" action="<?php echo e(url('/show')); ?>">
                                        <?php echo e(csrf_field()); ?>

                                        <button type="submit" onclick="updateTextArea()" id="notification-btn" form="withButton" class="no-vision mb-2 btn-primary" name="Submit">Potvrdiť</button>
                                        <?php $__currentLoopData = $films; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $film): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><input type="hidden" name="id" value="<?php echo e($film->id); ?>">  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <input type="hidden" name="nameDisplay" id="nameDisplay" value="nameDisplay">
                                        <input type="hidden" name="NumberDisplay" id="NumberDisplay" value="NumberDisplay">
                                        <input type="hidden" name="seatsDisplay" id="seatsDisplay" value="seatsDisplay">
                                    </form>
                                </div>
                            </div>
                        </div>
                        <ul class="seat-Info">
                            <li class="Box greenBox">Vybrané sedadlá</li>
                            <li class="Box redBox">Rezervované sedadlá</li>
                            <li class="Box orangeBox">Kúpené sedadlá</li>
                            <li class="Box whiteBox">Voľné sedadlá</li>
                        </ul>
                        <div class="seatStructure txt-center scroll">
                            <div class="screen">
                                <h2 class="screen-text text-center">Plátno</h2>
                            </div>  
                            <table id="seatsBlock">
                                <h2 id="notification"></h2>
                                    <tr>    
                                        <td></td>
                                        <?php for($i = 1; $i <= $max_seat; $i++): ?> 
                                            <td><?php echo e($i); ?></td>
                                        <?php endfor; ?>
                                    </tr>
                                    <tr>
                                <?php $__currentLoopData = $sedadla; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sedadlo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 

                                        <?php if($sedadlo->seat == 1): ?>
                                            <td><?php echo e($sedadlo->row); ?></td>
                                        <?php endif; ?>
                                        <?php if($sedadlo->taken == 0): ?>
                                            <td><input type="checkbox" class="seats" value="<?php echo e(' R' . $sedadlo->row . '/S' . $sedadlo->seat); ?>"></td>
                                        <?php elseif($sedadlo->taken == 1): ?>            
                                            <td><input type="checkbox" onclick="return false;" class="seats" value="<?php echo e(' R' . $sedadlo->row . '/S' . $sedadlo->seat); ?>"></td>
                                        <?php else: ?>
                                            <td><input type="checkbox" onclick="return false;" class="seats orange" value="<?php echo e(' R' . $sedadlo->row . '/S' . $sedadlo->seat); ?>"></td>
                                        <?php endif; ?>
                                    <?php if($sedadlo->seat == $max_seat): ?>
                                    </tr>
                                    <?php endif; ?>      
                                    
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                            </table>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>

    <script src="js/jquery-2.2.3.min.js"></script>

    <script>
        function onLoaderFunc() {
            document.getElementById("confirm-btn").style.display='block';
            $(".seatStructure *").prop("disabled", true);
        }

        function takeData() {
            if (($("#Username").val().length == 0) || ($("#Numseats").val().length == 0) || ($("#Numseats").val() > 6)) {
                alert("Please Enter your Name and Number of Seats");
            } else {
                $(".inputInfo *").prop("disabled", true);
                $(".seatStructure *").prop("disabled", false);
                document.getElementById("notification").innerHTML =
                    "<b style='margin-bottom:0px;font-size:x-large;color:white;letter-spacing:1px;'>Teraz si môžete vybrať sedadlá!</b>";
                document.getElementById("confirm-btn").style.display='none';
                
            }
        }

        function updateTextArea() {
            if ($("input:checked").length == ($("#Numseats").val())) {
                $(".seatStructure *").prop("disabled", true);

                var allNameVals = [];
                var allNumberVals = [];
                var allSeatsVals = [];

                allNameVals.push($("#Username").val());
                allNumberVals.push($("#Numseats").val());
                $('#seatsBlock :checked').each(function () {
                    allSeatsVals.push($(this).val());
                });

                $('#nameDisplay').val(allNameVals);
                $('#NumberDisplay').val(allNumberVals);
                $('#seatsDisplay').val(allSeatsVals);

            } else {
                alert("Please select " + ($("#Numseats").val()) + " seats");
            }
        }

        function myFunction() {
            alert($("input:checked").length);
        }

        $(":checkbox").click(function () {
            if ($("input:checked").length == ($("#Numseats").val())) {
                $(":checkbox").prop('disabled', true);
                $(':checked').prop('disabled', false);
                document.getElementById("notification-btn").style.display='block';
                document.getElementById("notification").innerHTML =
                    "";
            } else {
                $(":checkbox").prop('disabled', false);
                document.getElementById("notification-btn").style.display='none';
                document.getElementById("notification").innerHTML =
                    "<b style='margin-bottom:0px;font-size:x-large;color:white;letter-spacing:1px;'>Teraz si môžete vybrať sedadlá!</b>";
            }
        });
    </script>

    </body>
</html>
