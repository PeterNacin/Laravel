<?php $__env->startSection('content'); ?>

 	<div class="container">
    	<div class="panel panel-primary">
       		<div class="panel-heading"></div>
          	<div class="panel-body"> 
				<div class="row">
					<div class="col-md-10 col-md-offset-1">
						<div class="panel heading"><h4>Zoznam smien</h4></div>
						<div class="row">
							<div class="col-md-3">
								Mená: 
								<a href="/admin/eventslist/?name=asc">Vzostupne</a> |
								<a href="/admin/eventslist/?name=desc">Zostupne</a>
							</div>
							<div class="col-md-3">
								Dátum: 
								<a href="/admin/eventslist/?event_time=asc">Vzostupne</a> |
								<a href="/admin/eventslist/?event_time=desc">Zostupne</a> |
								<a href="/admin/eventslist/">Obnoviť</a>
							</div>
						</div>
						<div class="panel-body">
							<div class="col-md-5">
								<table style="width:100%">
									<h3>Hlási sa</h3>
									<tr>
										<th>Zamestnanec</th>
    									<th>Deň</th> 
    								</tr>
									<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<?php if(strpos($event->event_name, ' --- ') !== false): ?> 
											<td><?php echo e($event->event_name); ?></td>
											<td><?php echo e(date("d.m.Y", strtotime($event->start_date))); ?></td>
											<td><a href="/admin/deleteevents/<?php echo e($event->id); ?>'" onclick="return confirm('Skutočne chcete tento záznam vymazať?');">Vymazať</a></td>
							 			<?php endif; ?>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</table>
							</div>
						</div>
					</div>
					<div class="col-md-10 col-md-offset-1">
						<div class="panel heading"></div>
						<div class="panel-body">
							<div class="col-md-8">
								<table style="width:100%">
									<h3>Nahlásený</h3>
									<tr>
										<th>Zamestnanec</th>
    									<th>Príchod</th> 
    									<th>Odchod</th>
    								</tr>
									<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<?php if(strpos($event->event_name, ' ==> ') !== false): ?>
												<td><?php echo e($event->event_name); ?></td>
												<td><?php echo e(date("d.m.Y H:i", strtotime($event->start_date))); ?></td>
												<td><?php echo e(date("d.m.Y H:i", strtotime($event->end_date))); ?></td>
												<td><a href="<?php echo e(url('/admin/editevents',$event->id)); ?>">Upraviť</a></td>
												<td><a href="/admin/deleteevents/<?php echo e($event->id); ?>'" onclick="return confirm('Skutočne chcete tento záznam vymazať?');">Vymazať</a></td>
							 				<?php endif; ?>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</table>
							</div>
						</div>
						<div class="text-center"> <?php echo e($events->links()); ?></div>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admincalendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>