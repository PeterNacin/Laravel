<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Fonts -->
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet" type="text/css">

    <!-- Styles -->
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.css"/>
 
 
</head>
<body>
    <div id="app">
        <nav class="navbar navbar-expand-md navbar-light navbar-laravel navigation-bar">
            <div class="container">
                <!--<a class="navbar-brand" href="<?php echo e(url('/')); ?>">
                    Domov
                </a>-->
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav mr-auto">
                        <!-- Authentication Links -->
                            <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="li-a-white nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    Filmy <span class="caret"></span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-left" aria-labelledby="navbarDropdown">
                                    <a class="nav-link" href="/movies/?day=0"><?php echo e(date("d.m", strtotime("+0 day"))); ?></a>
                                    <a class="nav-link" href="/movies/?day=1"><?php echo e(date("d.m", strtotime("+1 day"))); ?></a>
                                    <a class="nav-link" href="/movies/?day=2"><?php echo e(date("d.m", strtotime("+2 day"))); ?></a>
                                    <a class="nav-link" href="/movies/?day=3"><?php echo e(date("d.m", strtotime("+3 day"))); ?></a>
                                    <a class="nav-link" href="/movies/?day=4"><?php echo e(date("d.m", strtotime("+4 day"))); ?></a>
                                    <a class="nav-link" href="/movies/?day=5"><?php echo e(date("d.m", strtotime("+5 day"))); ?></a>
                                    <a class="nav-link" href="/movies/?day=6"><?php echo e(date("d.m", strtotime("+6 day"))); ?></a>
                                </div>
                            </li>                            <li class="nav-item">
                                <a class="li-a-white nav-link" href="<?php echo e(url('news')); ?>"><?php echo e(__('Novinky')); ?></a>
                            </li>
                        
                        
                    </ul>

                    <!-- Right Side Of Navbar -->
                    
                    <ul class="navbar-nav ml-auto">
                        <?php if(auth()->guard()->guest()): ?>
                            <?php if(auth()->guard('admin')->check() == 0): ?>
                            <li class="nav-item dropdown">
                            <a id="navbarDropdown" class="li-a-white nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    Prihlásiť sa <span class="caret"></span>
                                </a>
                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                    <a class="nav-link" href="<?php echo e(route('login')); ?>"><?php echo e(__('Zamestnanec')); ?></a>
                                    <a class="nav-link" href="<?php echo e(route('admin.login')); ?>"><?php echo e(__('Manažér')); ?></a>
                                </div>
                            </li>

                            <?php endif; ?>
                        <?php endif; ?>
                        <?php if(auth()->guard()->check()): ?>
                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    Zamestnanec <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                     <a class="dropdown-item" href="<?php echo e(url('/home')); ?>">
                                        <?php echo e(__('Profil')); ?>

                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Odhlásiť sa')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                        <?php if(auth()->guard('admin')->check()): ?>

                            <li class="nav-item dropdown">
                                <a id="navbarDropdown" class="nav-link dropdown-toggle" href="#" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" v-pre>
                                    Manažér <span class="caret"></span>
                                </a>

                                <div class="dropdown-menu dropdown-menu-right" aria-labelledby="navbarDropdown">
                                     <a class="dropdown-item" href="<?php echo e(url('/admin')); ?>">
                                        <?php echo e(__('Profil')); ?>

                                    </a>
                                    <a class="dropdown-item" href="<?php echo e(route('logout')); ?>"
                                       onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                        <?php echo e(__('Odhlásiť sa')); ?>

                                    </a>

                                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                                        <?php echo csrf_field(); ?>
                                    </form>
                                </div>
                            </li>
                        <?php endif; ?>
                        
                    </ul>
                </div>
            </div>
        </nav>
            <?php echo $__env->yieldContent('content'); ?>
    </div>

        <!-- Scripts -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>

</body>
</html>
