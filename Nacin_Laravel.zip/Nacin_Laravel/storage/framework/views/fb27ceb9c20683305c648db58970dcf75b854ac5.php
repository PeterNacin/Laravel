<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.0/fullcalendar.min.css"/>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="panel panel-primary">
      <div class="panel-heading"></div>
      <div class="panel-body"> 
        <?php echo Form::open(array('route' => 'admin.events.add','method'=>'POST','files'=>'true')); ?>

          <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
              <?php if(Session::has('success')): ?>
                <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
              <?php elseif(Session::has('warnning')): ?>
                <div class="alert alert-danger"><?php echo e(Session::get('warnning')); ?></div>
              <?php endif; ?>
            </div>
            <div class="col-xs-10 col-sm-6 col-md-3">
              <div class="form-group">
                <?php echo Form::label('event_name','Zamestnanec:'); ?>

                <div class="">
                  <label class="sr-only" for="inlineFormInputName2">Name</label>
                  <select class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="event_name">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo $user->name; ?>"><?php echo e($user->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                  <?php echo $errors->first('event_name', '<p class="alert alert-danger">:message</p>'); ?>

                </div>
              </div>
            </div>
            <div class="col-xs-10 col-sm-6 col-md-2">
              <div class="form-group">
                <?php echo Form::label('event_name','Pozícia:'); ?>

                <div class="">
                  <label class="sr-only">Name</label>
                  <select class="form-control mb-2 mr-sm-2" name="position">
                    <option class="red" value="otvárač">Otvárač</option>
                    <option class="orange" value="zatvárač">Zatvárač</option>
                    <option class="violet" value="výpomoc floor">Floor výpomoc</option>
                    <option class="yellow" value="pokladňa">Pokladňa</option>
                    <option class="green" value="buffet">Buffet</option>
                    <option class="light-green" value="výpomoc buffet">Buffet výpomoc</option>
                  </select>
                  <?php echo $errors->first('event_name', '<p class="alert alert-danger">:message</p>'); ?>

                </div>
              </div>
            </div>
            <div class="col-xs-10 col-sm-6 col-md-2">
              <div class="form-group">
                <?php echo Form::label('start_date','Deň:'); ?>

                <div class="">
                  <input type="date" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="start_date" value="<?php echo date('Y-m-d'); ?>" /> 
                      <?php echo $errors->first('start_date', '<p class="alert alert-danger">:message</p>'); ?>

                </div>
              </div>
            </div>
            <div class="col-xs-10 col-sm-6 col-md-2">
              <div class="form-group">
                <?php echo Form::label('start_date','Čas:'); ?>

                <div class="">
                  <input type="time" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="start_time" value="<?php echo date('H:i'); ?>" />   <input type="time" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="end_time" value="<?php echo date('H:i'); ?>" />  
                      <?php echo $errors->first('start_date', '<p class="alert alert-danger">:message</p>'); ?>

                </div>
              </div>
            </div>
            <div class="col-xs-3 col-sm-3 col-md-1 text-center"> &nbsp;<br/>
              <div class="form-group">
              <button type="submit" class="btn btn-primary mb-2 botbot">Pridať</button>
            </div>
            </div>
          </div>
        <?php echo Form::close(); ?>

      </div>
    </div>
    <div class="text-center">
      <a href="/admin/events/?confirm=1">Nahlásený</a> |
      <a href="/admin/events/?confirm=0">Nenáhlasený</a> ---
      <a href="/admin/events/">Obnoviť</a>
    </div>
    <div class="row">
      <div class="text-center center-block">
        <div class="foo red"><strong>O</strong></div>
        <div class="foo orange"><strong>Z</strong></div>
        <div class="foo violet"><strong>Fv</strong></div>
        <div class="foo yellow"><strong>P</strong></div>
        <div class="foo green "><strong>B</strong></div>
        <div class="foo light-green "><strong>Bv</strong></div>      
      </div>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2">
          <div class="panel panel-default">
            <div class="panel-heading"></div>
            <div class="panel-body">
              <?php echo $calendar_details->calendar(); ?>

            </div>
          </div>
        </div>
      </div>
    </div>
  </div>  
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.0/fullcalendar.min.js"></script>

<?php echo $calendar_details->script(); ?>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.admincalendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>