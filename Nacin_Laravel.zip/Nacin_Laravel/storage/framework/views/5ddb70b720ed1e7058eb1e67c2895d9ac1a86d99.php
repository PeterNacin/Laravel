<?php $__env->startSection('content'); ?>

 	<div class="container">
    	<div class="panel panel-primary">
       		<div class="panel-heading"></div>
          	<div class="panel-body"> 
				<div class="row">	
					<div class="col-md-10 col-md-offset-1">
						<div class="panel heading"></div>
						<div class="row">
                    		<ul class="navbar-nav ml-auto">
								<div class="col-md-12 col-xs-12">
									
                        			        <form action="/admin/reservationlist/search" method="POST" role="search">
    											<?php echo e(csrf_field()); ?>

			    								<div class="input-group">
       												<input type="text" class="form-control" name="q"
            										placeholder="Číslo/Email"> <span class="input-group-btn">
            										<button type="submit" class="btn btn-default">
                									<span class="glyphicon glyphicon-search"></span></button></span>
	    										</div>
											</form>
                                			<form action="/admin/reservationlist/search" method="POST" role="search">
		    									<?php echo e(csrf_field()); ?>

			    								<div class="input-group">
        											<input type="date" class="form-control" name="q"
            										placeholder="Vyhľadať dátum rezervácie"> <span class="input-group-btn">
            										<button type="submit" class="btn btn-default">
                									<span class="glyphicon glyphicon-search"></span></button></span>
    											</div>
											</form>
                            			
								</div>
							</ul>
						</div>
						<div class="panel-body">
							<?php if(Session::has('success')): ?>
                    			<div class="alert alert-success"><h4><?php echo e(Session::get('success')); ?></h4></div>
                    		<?php endif; ?>
							<?php if(isset($reservations)): ?>
							<div class="col-md-12 col-xs-12 scroll">
								<table class="table">
  									<thead>
  										<h3>Rezervácie</h3>
										<tr>
											<th scope="col">Číslo</th>
											<th scope="col">Email</th>
											<th scope="col">Vypršaná rezervácie</th>
    										<th scope="col">Rezervované v čase</th>
    									</tr>
  									</thead>
  									<tbody>
  									<?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e($reservation->id); ?></td>
											<td><?php echo e($reservation->email); ?></td>
											<td><?php if($reservation->expired == '1'): ?> Áno  <?php else: ?> Nie <?php endif; ?> </td>
											<td><?php echo e($reservation->created_at); ?></td>	
											<td><a href="<?php echo e(url('/admin/showreservation',$reservation->id)); ?>">Zobraziť</a></td>
										</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
							<div class="col-md-12 col-xs-12 text-center">
								<?php echo $reservations->render(); ?>

							</div>
							<?php else: ?>
							<div class="panel-body">
								<div class="col-md-12 col-xs-12 text-center">
									<?php if(Session::has('error')): ?>
                    					<div class="alert alert-danger"><h4><?php echo e(Session::get('error')); ?></h4></div>
                    				<?php endif; ?>
                    			</div>
                    		</div>
                    		<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admincalendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>