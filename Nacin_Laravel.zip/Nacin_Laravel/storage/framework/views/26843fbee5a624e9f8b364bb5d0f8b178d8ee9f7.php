<?php $__env->startSection('style'); ?>
<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.0/fullcalendar.min.css"/>
<?php $__env->stopSection(); ?>
 
<?php $__env->startSection('content'); ?>
  <div class="container">
    <div class="panel panel-primary">
      <div class="panel-heading"></div>
      <div class="panel-body">    
        <?php echo Form::open(array('route' => 'events.add','method'=>'POST','files'=>'true')); ?>

          <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12">
              <?php if(Session::has('success')): ?>
                <div class="alert alert-success"><?php echo e(Session::get('success')); ?></div>
              <?php elseif(Session::has('warnning')): ?>
                <div class="alert alert-danger"><?php echo e(Session::get('warnning')); ?></div>
              <?php endif; ?>
            </div>
            <div class="col-xs-10 col-sm-6 col-md-3">
              <div class="form-group">
                <?php echo Form::label('event_name','Pozícia:'); ?>

                <div class="">
                  <label class="sr-only" for="inlineFormInputName2">Name</label>
                  <select class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="event_name">
                    <option value="otvárač">Otvárač</option>
                    <option value="zatvárač">Zatvárač</option>
                    <option value="buffet">Buffet</option>
                    <option value="výpomoc floor">Výpomoc floor</option>
                    <option value="výpomoc buffet">Výpomoc buffet</option>
                    <option value="pokladňa">Pokladňa</option>
                  </select>
                  <?php echo $errors->first('event_name', '<p class="alert alert-danger">:message</p>'); ?>

                </div>
              </div>
            </div>
            <div class="col-xs-10 col-sm-6 col-md-3">
              <div class="form-group">
                <?php echo Form::label('start_date','Deň:'); ?>

                <div class="">
                  <input type="date" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="start_date" value="<?php echo date('Y-m-d'); ?>">
                  <?php echo $errors->first('start_date', '<p class="alert alert-danger">:message</p>'); ?>

                </div>
              </div>
            </div>
              <div class="col-xs-3 col-sm-3 col-md-1 text-center"> &nbsp;<br/>
                <button type="submit" class="btn btn-primary mb-2 botbot">Pridať</button>
              </div>
            </div>
          <?php echo Form::close(); ?>

        </div>
      </div>
    </div>
    <div class="text-center">
      <a href="/events/?my=1">Moje smeny</a> ---
      <a href="/events/">Obnoviť</a>
    </div>
    <div class="container">
      <div class="row">
        <div class="col-md-8 col-md-offset-2">
          <div class="panel panel-default">
            <div class="panel-heading"></div>
			      <div class="panel-body">
              <?php echo $calendar_details->calendar(); ?>

            </div>
          </div>
         </div>
       </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.9.0/moment.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.10.0/fullcalendar.min.js"></script>
<?php echo $calendar_details->script(); ?>



<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.calendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>