<?php $__env->startSection('content'); ?>

 	<div class="container">
    	<div class="panel panel-primary">
       		<div class="panel-heading"></div>
          	<div class="panel-body"> 
				<div class="row">	
					<div class="col-md-12 col-xs-12">
						<div class="panel heading"></div>
						<div class="panel-body">
							<?php if(Session::has('success')): ?>
                    			<div class="alert alert-success"><h4><?php echo e(Session::get('success')); ?></h4></div>
                    		<?php endif; ?>
							<?php if(isset($reservations)): ?>
							<div class="col-md-12 col-xs-12 scroll">
								<table class="table">
  									<thead>
  										<h3>Rezervácie</h3>
										<tr>
											<th scope="col">Číslo</th>
											<th scope="col">Email</th>
    										<th scope="col">Rada</th>
    										<th scope="col">Sedadlo</th>
    										<th scope="col">Názov filmu</th>
    										<th scope="col">Dátum</th>
    										<th scope="col">Čas</th>
    										<th scope="col">Sála</th>
    										<th scope="col">Rezervované v čase</th>
    									</tr>
  									</thead>
  									<tbody>
  									<?php $__currentLoopData = $reservations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reservation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e($reservation->id); ?></td>
											<td><?php echo e($reservation->email); ?></td>
											<td><?php echo e($reservation->row); ?></td>
											<td><?php echo e($reservation->seat); ?></td>
											<td><?php echo e($reservation->title); ?></td>
											<td><?php echo e($reservation->date); ?></td>
											<td><?php echo e($reservation->time); ?></td>
											<td><a href="<?php echo e(url('/film',$reservation->show_id)); ?>"><strong><?php echo e($reservation->hall); ?></strong></a></td>
											<td><?php echo e($reservation->created_at); ?></td>
										</tr>
									<tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tr>
									</tbody>
								</table>
							</div>
							<div class="col-md-12 col-xs-12 col-md-offset-5 col-xs-offset-5">
								<?php if($reservation->expired == '0'): ?><td><a href="/admin/confirmreservation/<?php echo e($reservation->id); ?>" class="btn btn-primary mb-2" onclick="return confirm('Skutočne chcete tento záznam potvrdiť?');">Potvrdiť</a></td><?php endif; ?>
							</div>
                    		<?php endif; ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admincalendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>