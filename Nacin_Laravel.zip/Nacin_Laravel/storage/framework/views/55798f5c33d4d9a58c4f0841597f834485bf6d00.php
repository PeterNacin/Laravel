<div>
	<strong><?php echo e($data[0]); ?></strong> <br>
    Film : <?php echo e($data[1]); ?> <br>
    Deň : <?php echo e($data[2]); ?> <br>
    Čas : <?php echo e($data[3]); ?> <br>
    Sála : <?php echo e($data[4]); ?> <br>
    Sedadlá : <?php echo e($data[5]); ?> <br>
</div>