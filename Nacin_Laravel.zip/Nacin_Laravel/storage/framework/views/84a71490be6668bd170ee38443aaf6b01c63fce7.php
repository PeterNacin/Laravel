<?php $__env->startSection('content'); ?>
<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<div class="panel heading"></div>

				<div class="panel-body">

			<form method="POST" action="<?php echo e(url('/admin/updateevents')); ?>">
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="id" value="<?php echo e($id); ?>">
				<table>
					<tr>
						<td>Meno</td>
						<td><input type="text" name="name" value="<?php echo e($event->name); ?>"></td>
					</tr>
				
				</table>
			</form>
			</div>
			</div>
		</div>
	</div>


				

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admincalendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>