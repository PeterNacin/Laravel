<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="panel panel-primary">
    <div class="panel-heading"></div>
    <div class="panel-body"> 
      <div class="row">
        <div class="col-md-4 col-xs-10 col-md-offset-1 col-xs-offset-1"">
          <div class="panel heading"><h4>Úprava smeny</h4></div>
          <div class="row">  
						<form method="POST" action="<?php echo e(url('/updateevents')); ?>">
							<?php echo e(csrf_field()); ?>

							<input type="hidden" name="id" value="<?php echo e($id); ?>">
							<table>
                <tr>
                  <td><strong>Meno</strong></td>
                  <td>
                    <select class="form-control mb-2 mr-sm-2" name="event_name">
                      <option value=""><?php echo e(Auth::user()->name); ?></option>
                    </select></td>
                </tr>
                <tr>
                  <td><strong>Pozícia</strong></td>
                  <td>
                    <select class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="position">
                      <option value="otvarac">Otvárač</option>
                      <option value="zatvarac">Zatvárač</option>
                      <option value="buffet">Buffet</option>
                      <option value="vypomoc floor">Výpomoc floor</option>
                      <option value="vypomoc buffet">Výpomoc buffet</option>
                      <option value="pokladna">Pokladňa</option>
                    </select>
                  </td>
                </tr>
                <tr>
                  <td><strong>Deň</strong></td>
                  <td>
                      <input type="datetime" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="start_date" value="<?php echo e(date("Y-m-d", strtotime($event->start_date))); ?>" /> 
                    </td>
                </tr>
                <tr>
                  <td><input type="submit" class="btn btn-primary mb-2" name="Submit" value="Zmeniť"></td>
                </tr>
              </table> 
						</form>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.calendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>