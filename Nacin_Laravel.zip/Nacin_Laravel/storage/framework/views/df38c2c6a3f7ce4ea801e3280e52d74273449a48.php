<?php $__env->startSection('content'); ?>

 	<div class="container">
    	<div class="panel panel-primary">
       		<div class="panel-heading"></div>
          	<div class="panel-body"> 
				<div class="row">
					<div class="col-md-10 col-xs-12 col-md-offset-1 col-xs-offset-0">
						<div class="panel heading"><h4>Zoznam zamestnancov</h4></div>
						<div class="row">
							<div class="col-md-6 col-xs-12">
								<strong>Zoradiť:  </strong>
								Floor <a href="/admin/list/?floor=1">Áno</a> |
								<a href="/admin/list/?floor=0">Nie</a> ---
								Buffet <a href="/admin/list/?buffet=1">Áno</a> |
								<a href="/admin/list/?buffet=0">Nie</a> ---
								Pokladňa <a href="/admin/list/?pokladna=1">Áno</a> |
								<a href="/admin/list/?pokladna=0">Nie</a> ---
								<a href="/admin/list/">Obnoviť</a>
							</div>
							<div class="col-md-6 col-xs-6">
								<strong> Mená: </strong>
								<a href="/admin/list/?sort=asc">Vzostupne</a> |
								<a href="/admin/list/?sort=desc">Zostupne</a>
							</div>
							<ul class="navbar-nav ml-auto">
								<div class="col-md-10 col-xs-12">
									
                        			        <form action="/admin/list/search" method="POST" role="search">
    											<?php echo e(csrf_field()); ?>

			    								<div class="input-group">
       												<input type="text" class="form-control" name="q"
            										placeholder="Vyhľadať zamestnanca"> <span class="input-group-btn">
            										<button type="submit" class="btn btn-default">
                									<span class="glyphicon glyphicon-search"></span></button></span>
	    										</div>
											</form>
                            			
								</div>
							</ul>
						</div>
						<?php if(isset($users)): ?>
						<div class="panel-body">
							<div class="col-md-12 col-xs-12 scroll">
								<table class="table">
  									<thead>
    									<tr>
      										<th scope="col">Meno</th>
    										<th scope="col">Email</th> 
    										<th scope="col">Číslo</th> 
    										<th scope="col">Floor</th> 
    										<th scope="col">Buffet</th> 
    										<th scope="col">Pokladňa</th>
    									</tr>
  									</thead>
  									<tbody>
  										<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    									<tr>
											<td><?php echo e($user->name); ?></td>
											<td><?php echo e($user->email); ?></td>
											<td><?php echo e($user->phone); ?></td>
											<td><?php if($user->floor == '1'): ?> Áno  <?php else: ?> Nie <?php endif; ?> </td>
											<td><?php if($user->buffet == '1'): ?> Áno  <?php else: ?> Nie <?php endif; ?> </td>
											<td><?php if($user->pokladna == '1'): ?> Áno  <?php else: ?> Nie <?php endif; ?> </td>
											<td><a href="<?php echo e(url('/admin/edit',$user->id)); ?>">Upraviť</a></td>
											<td><a href="/admin/delete/<?php echo e($user->id); ?>'" onclick="return confirm('Skutočne chcete tento záznam vymazať?');">Vymazať</a></td>
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>	
  									</tbody>
								</table>
							</div>
							<div class="col-md-12 col-xs-12 text-center">
								<?php echo $users->render(); ?>

							</div>
						</div>
					</div>
					<?php else: ?>
						<div class="panel-body">
							<div class="col-md-12 col-xs-12 scroll">
								<?php if(Session::has('error')): ?>
                    				<div class="alert alert-danger"><h4><?php echo e(Session::get('error')); ?></h4></div>
                    			<?php endif; ?>
                    		</div>
                    	</div>
                    <?php endif; ?>
				</div>
				<div class="col-md-10 col-xs-12 col-md-offset-1">
					<div class="panel heading"><h4>Zoznam Manažérov</h4></div>
					<div class="panel-body">
						<div class="col-md-12 col-xs-12 scroll">
							<table class="table">
								<thead>
								<tr>			
									<th scope="col">Meno</th>
    								<th scope="col">Email</th> 
    								<th scope="col">Číslo</th> 
    							</tr>
    							</thead>
    							<tbody>
								<?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($admin->name); ?></td>
										<td><?php echo e($admin->email); ?></td>
										<td><?php echo e($admin->phone); ?></td>
										<td><a href="/admin/deleteadmin/<?php echo e($admin->id); ?>'" onclick="return confirm('Skutočne chcete tento záznam vymazať?');">Vymazať</a></td>
									</tr>
								</tbody>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</table>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admincalendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>