<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="panel panel-primary">
    <div class="panel-heading"></div>
    <div class="panel-body"> 
      <div class="row">
        <div class="col-md-4 col-xs-10 col-md-offset-1 col-xs-offset-1">
          <div class="panel heading"><h4>Úprava filmu</h4></div>
            <div class="row">  
							<form method="POST" id="withText" action="<?php echo e(url('/admin/updatemovies')); ?>">
								<?php echo e(csrf_field()); ?>

								<input type="hidden" name="id" value="<?php echo e($id); ?>">
                <table>
                  <tr>
                    <td><strong>Titul</strong></td>
                    <td><input type="text" class="form-control mb-2 mr-sm-2" name="title" value="<?php echo e($movie->title); ?>"></td>
                  </tr>
                  <tr>
                    <td><strong>Stav</strong></td>
                    <td>
                      <select class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="active">
                          <option value="0">Neaktívny</option>
                          <option value="1">Hraný</option>
                          <option value="2">Novinky</option>
                        </select>
                    </td>
                  </tr>
                  <tr>
                    <td><strong>Trvanie</strong></td>
                    <td><input type="number" class="form-control mb-2 mr-sm-2" name="length" value="<?php echo e($movie->length); ?>"></td>
                  </tr>
                  <tr>
                    <td><strong>Jazyk</strong></td>
                    <td><input type="text" class="form-control mb-2 mr-sm-2" name="language" value="<?php echo e($movie->language); ?>"></td>
                  </tr>
                  <tr>
                    <td><strong>Žáner</strong></td>
                    <td><input type="text" class="form-control mb-2 mr-sm-2" name="genre" value="<?php echo e($movie->genre); ?>"></td>
                  </tr>
                  <tr>
                    <td><strong>Obrázok</strong></td>
                    <td>
                      <input type="file" accept=".png,.jpg" class="mb-2 mr-sm-2" name="image" value="<?php echo e($movie->image); ?>" required>
                    </td>
                  </tr>
            
                  <tr>
                    <td><strong>Popis</strong></td>
                    <td><textarea class="form-control mb-2 mr-sm-2" form="withText" rows="4" cols="30" name="info" ><?php echo e($movie->info); ?></textarea></td>
                  </tr>

                  
                  <tr>
                    <td><input type="submit" class="btn btn-primary mb-2" name="Submit" value="Zmeniť"></td>
                  </tr>
                  
                </table> 
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admincalendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>