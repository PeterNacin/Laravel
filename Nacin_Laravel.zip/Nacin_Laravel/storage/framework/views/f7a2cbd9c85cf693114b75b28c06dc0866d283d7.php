<?php $__env->startSection('content'); ?>

   <div class="container">
    	<div class="panel panel-primary">
       		<div class="panel-heading"></div>
          	<div class="panel-body"> 
				<div class="row">
					<div class="col-md-4 col-xs-10 col-md-offset-1 col-xs-offset-1">
						<div class="panel heading"><h4>Pridať film</h4></div>
						<div class="row">
							<form method="POST" id="withText" action="/admin/insertmovie">
								<table>
									<tr>
										<?php echo e(csrf_field()); ?>

										<td><strong>Názov: </strong></td>
										<td><input type="text" class="form-control mb-2 mr-sm-2" name="title" required></td>
									</tr>
									<tr>
										<td><strong>Hraný: </strong></td>
										<td><select class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="active">
                          					<option value="0">Neaktívny</option>
                        					<option value="1" selected>Aktívny</option>
                          					<option value="2">Novinky</option>
                        				</select></td>
									</tr>
									<tr>
										<td><strong>Trvanie: </strong></td>
										<td>
											<input type="number" class="form-control mb-2 mr-sm-2" name="length" required>
										</td>
									</tr>
									<tr>
										<td><strong>Žáner: </strong></td>
										<td>
											<input type="text" class="form-control mb-2 mr-sm-2" name="genre" required>
										</td>
									</tr>
									<tr>
										<td><strong>Jazyk: </strong></td>
										<td>
											<input type="text" class="form-control mb-2 mr-sm-2" name="language" required>
										</td>
									</tr>
									<tr>
										<td><strong>Obrázok: </strong></td>
										<td>
											<input type="file" accept=".png,.jpg" class="mb-2 mr-sm-2" name="image" placeholder="Názov obrázku" required>
										</td>
									</tr>
									<tr>
                    					<td><strong>Popis: </strong></td>
                    					<td><textarea class="form-control mb-2 mr-sm-2" form="withText" rows="4" cols="30" name="info" >Popis filmu ...</textarea></td>
                  					</tr>
									<tr>
										<td><input type="submit" class="btn btn-primary mb-2" name="sumbit" value="Pridať"></td>
									</tr>
								</table>
							</form>
							<br>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admincalendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>