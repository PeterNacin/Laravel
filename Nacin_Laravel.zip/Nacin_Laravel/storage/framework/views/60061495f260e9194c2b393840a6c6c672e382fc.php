<?php $__env->startSection('content'); ?>

 	<div class="container">
    	<div class="panel panel-primary">
       		<div class="panel-heading"></div>
          	<div class="panel-body"> 
				<div class="row">		
					<div class="col-md-10 col-md-offset-1">
						<div class="panel heading"><h4>Zoznam Manažérov</h4></div>
						<div class="panel-body">
							<div class="col-md-7">
							<table style="width:100%">
								<tr>
									<th>Meno</th>
    								<th>Email</th> 
    								<th>Číslo</th> 
    							</tr>
								<?php $__currentLoopData = $admins; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $admin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td><?php echo e($admin->name); ?></td>
										<td><?php echo e($admin->email); ?></td>
										<td><?php echo e($admin->phone); ?></td>
									</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td>Cinemax Trenčín</td>
										<td>cinemax@mail.com></td>
										<td>123456789</td>
									</tr>
							</table>
						</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.calendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>