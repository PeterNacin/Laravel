
<!--
	Author: W3layouts
	Author URL: http://w3layouts.com
	License: Creative Commons Attribution 3.0 Unported
	License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE html>
<html lang="zxx">

<head>
    <title>Movie Seat Selection Flat Responsive Widget Template :: w3layouts</title>
    <!-- Meta-Tags -->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta charset="utf-8">
    <meta name="keywords" content="Movie Seat Selection a Responsive Web Template, Bootstrap Web Templates, Flat Web Templates, Android Compatible Web Template, Smartphone Compatible Web Template, Free Webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola Web Design">
    <script>
        addEventListener("load", function () {
            setTimeout(hideURLbar, 0);
        }, false);

        function hideURLbar() {
            window.scrollTo(0, 1);
        }
    </script>
    <!-- //Meta-Tags -->
    <!-- Index-Page-CSS -->
     <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('css/style.css')); ?>" rel="stylesheet"> 
    <!-- //Custom-Stylesheet-Links -->
    <!--fonts -->
    <link href="//fonts.googleapis.com/css?family=Source+Sans+Pro:200,200i,300,300i,400,400i,600,600i,700,700i,900,900i" rel="stylesheet">
    <!-- //fonts -->
</head>

<body onload="onLoaderFunc()">
<script src='//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js'></script><script src="//m.servedby-buysellads.com/monetization.js" type="text/javascript"></script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('flexbar', 'CKYI627U', 'placement:w3layoutscom');
  	}
})();
</script>
<script>
(function(){
if(typeof _bsa !== 'undefined' && _bsa) {
	// format, zoneKey, segment:value, options
	_bsa.init('fancybar', 'CKYDL2JN', 'placement:demo');
}
})();
</script>
<script>
(function(){
	if(typeof _bsa !== 'undefined' && _bsa) {
  		// format, zoneKey, segment:value, options
  		_bsa.init('stickybox', 'CKYI653J', 'placement:w3layoutscom');
  	}
})();
</script>
<script>
	(function(v,d,o,ai){ai=d.createElement("script");ai.defer=true;ai.async=true;ai.src=v.location.protocol+o;d.head.appendChild(ai);})(window, document, "//vdo.ai/core/w3layouts/vdo.ai.js");
	</script>
	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-125810435-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-125810435-1');
</script><script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','//www.google-analytics.com/analytics.js','ga');
ga('create', 'UA-30027142-1', 'w3layouts.com');
  ga('send', 'pageview');
</script>
<body>




<!---728x90--->

    <h1>Movie Seat Selection</h1>
    <div class="container">

        <div class="w3ls-reg">
            <!-- input fields -->
            <div class="inputForm">
                <h2>fill the required details below and select your seats</h2>
                <div class="mr_agilemain">
                    <div class="agileits-left">
                        <label> Name
                            <span>*</span>
                        </label>
                        <input type="text" id="Username" required>
                    </div>
                    <div class="agileits-right">
                        <label> Number of Seats
                            <span>*</span>
                        </label>
                        <input type="number" id="Numseats" required min="1">
                    </div>
                </div>
                <button onclick="takeData()">Start Selecting</button>
            </div>
            <!-- //input fields -->
			<!---728x90--->

            <!-- seat availabilty list -->
            <ul class="seat_w3ls">
                <li class="smallBox greenBox">Selected Seat</li>

                <li class="smallBox redBox">Reserved Seat</li>

                <li class="smallBox emptyBox">Empty Seat</li>
            </ul>
            <!-- seat availabilty list -->
            <!-- seat layout -->
            <div class="seatStructure txt-center" style="overflow-x:auto;">
                <table id="seatsBlock">
                    <p id="notification"></p>
                    <tr>
                        <td></td>
                        <td>1</td>
                        <td>2</td>
                        <td>3</td>
                        <td>4</td>
                        <td>5</td>
                        <td>6</td>
                        <td>7</td>
                        <td>8</td>
                        <td>9</td>
                        <td>10</td>
                        <td>11</td>
                        <td>12</td>
                    </tr>
                    <?php $__currentLoopData = $seats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $seat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <?php $count = substr_count($seat->A, ','); ?>
                        <?php if($count != 0): ?>
                            <?php $row_A = explode(',',$seat->A); ?>
                            <td>A</td>
                            <?php for($i = 1; $i <= $count+1; $i++): ?> 
                                <?php $A = $row_A[$i-1];    ?>
                                <?php if($row_A[$i-1] == 0): ?>
                                    <td><input type="checkbox" class="seats" value="<?php echo e('A'.$i); ?>"></td>
                                <?php else: ?>
                                    <td><input type="checkbox" onclick="return false;" class="seats" value="<?php echo e('A'.$i); ?>"></td>
                                <?php endif; ?>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <?php $count = substr_count($seat->B, ','); ?>
                        <?php if($count != 0): ?>
                            <?php $row_B = explode(',',$seat->B); ?>
                            <td>B</td>
                            <?php for($i = 1; $i <= $count+1; $i++): ?> 
                                <?php $B = $row_B[$i-1];    ?>
                                <?php if($row_B[$i-1] == 0): ?>
                                    <td><input type="checkbox" class="seats" value="<?php echo e('B'.$i); ?>"></td>
                                <?php else: ?>
                                    <td><input type="checkbox" onclick="return false;" class="seats" value="<?php echo e('B'.$i); ?>"></td>
                                <?php endif; ?>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <?php $count = substr_count($seat->C, ','); ?>
                        <?php if($count != 0): ?>
                            <?php $row_C = explode(',',$seat->C); ?>
                            <td>C</td>
                            <?php for($i = 1; $i <= $count+1; $i++): ?> 
                                <?php $C = $row_C[$i-1];    ?>
                                <?php if($row_C[$i-1] == 0): ?>
                                    <td><input type="checkbox" class="seats" value="<?php echo e('C'.$i); ?>"></td>
                                <?php else: ?>
                                    <td><input type="checkbox" onclick="return false;" class="seats" value="<?php echo e('C'.$i); ?>"></td>
                                <?php endif; ?>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <?php $count = substr_count($seat->D, ','); ?>
                        <?php if($count != 0): ?>
                            <?php $row_D = explode(',',$seat->D); ?>
                            <td>D</td>
                            <?php for($i = 1; $i <= $count+1; $i++): ?> 
                                <?php $D = $row_D[$i-1];    ?>
                                <?php if($row_D[$i-1] == 0): ?>
                                    <td><input type="checkbox" class="seats" value="<?php echo e('D'.$i); ?>"></td>
                                <?php else: ?>
                                    <td><input type="checkbox" onclick="return false;" class="seats" value="<?php echo e('D'.$i); ?>"></td>
                                <?php endif; ?>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <?php $count = substr_count($seat->E, ','); ?>
                        <?php if($count != 0): ?>
                            <?php $row_E = explode(',',$seat->E); ?>
                            <td>E</td>
                            <?php for($i = 1; $i <= $count+1; $i++): ?> 
                                <?php $E = $row_E[$i-1];    ?>
                                <?php if($row_E[$i-1] == 0): ?>
                                    <td><input type="checkbox" class="seats" value="<?php echo e('E'.$i); ?>"></td>
                                <?php else: ?>
                                    <td><input type="checkbox" onclick="return false;" class="seats" value="<?php echo e('E'.$i); ?>"></td>
                                <?php endif; ?>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <?php $count = substr_count($seat->F, ','); ?>
                        <?php if($count != 0): ?>
                            <?php $row_F = explode(',',$seat->F); ?>
                            <td>F</td>
                            <?php for($i = 1; $i <= $count+1; $i++): ?> 
                                <?php $F = $row_F[$i-1];    ?>
                                <?php if($row_F[$i-1] == 0): ?>
                                    <td><input type="checkbox" class="seats" value="<?php echo e('F'.$i); ?>"></td>
                                <?php else: ?>
                                    <td><input type="checkbox" onclick="return false;" class="seats" value="<?php echo e('F'.$i); ?>"></td>
                                <?php endif; ?>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <?php $count = substr_count($seat->G, ','); ?>
                        <?php if($count != 0): ?>
                            <?php $row_G = explode(',',$seat->G); ?>
                            <td>G</td>
                            <?php for($i = 1; $i <= $count+1; $i++): ?> 
                                <?php $G = $row_G[$i-1];    ?>
                                <?php if($row_G[$i-1] == 0): ?>
                                    <td><input type="checkbox" class="seats" value="<?php echo e('G'.$i); ?>"></td>
                                <?php else: ?>
                                    <td><input type="checkbox" onclick="return false;" class="seats" value="<?php echo e('G'.$i); ?>"></td>
                                <?php endif; ?>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <?php $count = substr_count($seat->H, ','); ?>
                        <?php if($count != 0): ?>
                            <?php $row_H = explode(',',$seat->H); ?>
                            <td>H</td>
                            <?php for($i = 1; $i <= $count+1; $i++): ?> 
                                <?php $H = $row_H[$i-1];    ?>
                                <?php if($row_H[$i-1] == 0): ?>
                                    <td><input type="checkbox" class="seats" value="<?php echo e('H'.$i); ?>"></td>
                                <?php else: ?>
                                    <td><input type="checkbox" onclick="return false;" class="seats" value="<?php echo e('H'.$i); ?>"></td>
                                <?php endif; ?>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <?php $count = substr_count($seat->I, ','); ?>
                        <?php if($count != 0): ?>
                            <?php $row_I = explode(',',$seat->I); ?>
                            <td>I</td>
                            <?php for($i = 1; $i <= $count+1; $i++): ?> 
                                <?php $I = $row_I[$i-1];    ?>
                                <?php if($row_I[$i-1] == 0): ?>
                                    <td><input type="checkbox" class="seats" value="<?php echo e('I'.$i); ?>"></td>
                                <?php else: ?>
                                    <td><input type="checkbox" onclick="return false;" class="seats" value="<?php echo e('I'.$i); ?>"></td>
                                <?php endif; ?>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <?php $count = substr_count($seat->J, ','); ?>
                        <?php if($count != 0): ?>
                            <?php $row_J = explode(',',$seat->J); ?>
                            <td>J</td>
                            <?php for($i = 1; $i <= $count+1; $i++): ?> 
                                <?php $J = $row_J[$i-1];    ?>
                                <?php if($row_J[$i-1] == 0): ?>
                                    <td><input type="checkbox" class="seats" value="<?php echo e('J'.$i); ?>"></td>
                                <?php else: ?>
                                    <td><input type="checkbox" onclick="return false;" class="seats" value="<?php echo e('J'.$i); ?>"></td>
                                <?php endif; ?>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <?php $count = substr_count($seat->K, ','); ?>
                        <?php if($count != 0): ?>
                            <?php $row_K = explode(',',$seat->K); ?>
                            <td>K</td>
                            <?php for($i = 1; $i <= $count+1; $i++): ?> 
                                <?php $K = $row_K[$i-1];    ?>
                                <?php if($row_K[$i-1] == 0): ?>
                                    <td><input type="checkbox" class="seats" value="<?php echo e('K'.$i); ?>"></td>
                                <?php else: ?>
                                    <td><input type="checkbox" onclick="return false;" class="seats" value="<?php echo e('K'.$i); ?>"></td>
                                <?php endif; ?>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <?php $count = substr_count($seat->L, ','); ?>
                        <?php if($count != 0): ?>
                            <?php $row_L = explode(',',$seat->L); ?>
                            <td>L</td>
                            <?php for($i = 1; $i <= $count+1; $i++): ?> 
                                <?php $L = $row_L[$i-1];    ?>
                                <?php if($row_L[$i-1] == 0): ?>
                                    <td><input type="checkbox" class="seats" value="<?php echo e('L'.$i); ?>"></td>
                                <?php else: ?>
                                    <td><input type="checkbox" onclick="return false;" class="seats" value="<?php echo e('L'.$i); ?>"></td>
                                <?php endif; ?>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </tr>
                    <tr>
                        <?php $count = substr_count($seat->M, ','); ?>
                        <?php if($count != 0): ?>
                            <?php $row_M = explode(',',$seat->M); ?>
                            <td>M</td>
                            <?php for($i = 1; $i <= $count+1; $i++): ?> 
                                <?php $M = $row_M[$i-1];    ?>
                                <?php if($row_M[$i-1] == 0): ?>
                                    <td><input type="checkbox" class="seats" value="<?php echo e('M'.$i); ?>"></td>
                                <?php else: ?>
                                    <td><input type="checkbox" onclick="return false;" class="seats" value="<?php echo e('M'.$i); ?>"></td>
                                <?php endif; ?>
                            <?php endfor; ?>
                        <?php endif; ?>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                
                </table>

                <div class="screen">
                    <h2 class="wthree">Screen this way</h2>
                </div>
                <button onclick="updateTextArea()">Confirm Selection</button>
            </div>
            <!-- //seat layout -->
            <!-- details after booking displayed here -->
            <div class="displayerBoxes txt-center" style="overflow-x:auto;">
                <table class="Displaytable w3ls-table" width="100%">
                    <tr>
                        <th>Name</th>
                        <th>Number of Seats</th>
                        <th>Seats</th>
                    </tr>
                    <tr>
                        <td>
                            <textarea id="nameDisplay"></textarea>
                        </td>
                        <td>
                            <textarea id="NumberDisplay"></textarea>
                        </td>
                        <td>
                            <textarea id="seatsDisplay"></textarea>
                        </td>
                    </tr>
                </table>
            </div>
            <!-- //details after booking displayed here -->
        </div>
    </div>
	<!---728x90--->

    <div class="copy-wthree">
        <p>© 2018 Movie Seat Selection . All Rights Reserved | Design by
            <a href="http://w3layouts.com/" target="_blank">W3layouts</a>
        </p>
    </div>
    <!-- js -->
    <script src="js/jquery-2.2.3.min.js"></script>
    <!-- //js -->
    <!-- script for seat selection -->
    <script>
        function onLoaderFunc() {
            $(".seatStructure *").prop("disabled", true);
            $(".displayerBoxes *").prop("disabled", true);
        }

        function takeData() {
            if (($("#Username").val().length == 0) || ($("#Numseats").val().length == 0)) {
                alert("Please Enter your Name and Number of Seats");
            } else {
                $(".inputForm *").prop("disabled", true);
                $(".seatStructure *").prop("disabled", false);
                document.getElementById("notification").innerHTML =
                    "<b style='margin-bottom:0px;background:#ff9800;letter-spacing:1px;'>Please Select your Seats NOW!</b>";
            }
        }


        function updateTextArea() {

            if ($("input:checked").length == ($("#Numseats").val())) {
                $(".seatStructure *").prop("disabled", true);

                var allNameVals = [];
                var allNumberVals = [];
                var allSeatsVals = [];

                //Storing in Array
                allNameVals.push($("#Username").val());
                allNumberVals.push($("#Numseats").val());
                $('#seatsBlock :checked').each(function () {
                    allSeatsVals.push($(this).val());
                });

                //Displaying 
                $('#nameDisplay').val(allNameVals);
                $('#NumberDisplay').val(allNumberVals);
                $('#seatsDisplay').val(allSeatsVals);
            } else {
                alert("Please select " + ($("#Numseats").val()) + " seats")
            }
        }


        function myFunction() {
            alert($("input:checked").length);
        }

        /*
        function getCookie(cname) {
            var name = cname + "=";
            var ca = document.cookie.split(';');
            for(var i = 0; i < ca.length; i++) {
                var c = ca[i];
                while (c.charAt(0) == ' ') {
                    c = c.substring(1);
                }
                if (c.indexOf(name) == 0) {
                    return c.substring(name.length, c.length);
                }
            }
            return "";
        }
        */


        $(":checkbox").click(function () {
            if ($("input:checked").length == ($("#Numseats").val())) {
                $(":checkbox").prop('disabled', true);
                $(':checked').prop('disabled', false);
            } else {
                $(":checkbox").prop('disabled', false);
            }
        });
    </script>
    <!-- //script for seat selection -->

</body>

</html>