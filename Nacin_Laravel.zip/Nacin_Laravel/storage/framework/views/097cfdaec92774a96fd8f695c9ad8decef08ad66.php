<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="panel panel-primary">
    <div class="panel-heading"></div>
    <div class="panel-body"> 
      <div class="row">
        <div class="col-md-4 col-xs-10 col-md-offset-1 col-xs-offset-1">
          <div class="panel heading"><h4>Vytvoriť premietanie filmu</h4></div>
            <div class="row">  
							<form method="POST" action="<?php echo e(url('/admin/insertshow')); ?>">
								<?php echo e(csrf_field()); ?>

								<input type="hidden" name="id" value="<?php echo e($id); ?>">
                <table>
                  <tr>
                    <td><strong>Titul</strong></td>
                    <td><input type="text" class="form-control mb-2 mr-sm-2" name="title" value="<?php echo e($movie->title); ?>" readonly></td>
                  </tr>
                  <tr>
                    <td><strong>Deň</strong></td>
                    <td>
                      <input type="date" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="date" value="<?php echo date('Y-m-d'); ?>" />  
                    </td>
                  </tr>
                  <?php if($movie->active == '1'): ?>
                  <tr>
                    <td><strong>Čas</strong></td>
                    <td>
                      <input type="time" class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="time" value="<?php echo date('H:i'); ?>" /> 
                    </td>
                  </tr>
                  
                  <tr>
                    <td><strong>Sála: </strong></td>
                    <td>
                      <select class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="hall">
                        <option value="new">bez sály</option>
                        <option value="A">A</option>
                        <option value="B">B</option>
                        <option value="C">C</option>
                        <option value="D">D</option>
                      </select>
                    </td>
                  </tr>
                  <?php else: ?>
                  <input type="hidden" name="time" value="new">
                  <input type="hidden" name="hall" value="new">
                  <?php endif; ?>
                  <tr>
                    <td><input type="submit" class="btn btn-primary mb-2" name="Submit" value="Pridať"></td>
                  </tr>
                  
                </table> 
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admincalendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>