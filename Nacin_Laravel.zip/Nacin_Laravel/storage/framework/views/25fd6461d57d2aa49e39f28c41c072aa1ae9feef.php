<?php $__env->startSection('content'); ?>
<div class="container">
		<div class="row">
			<div class="col-md-8 col-md-offset-2">
				<div class="panel heading"></div>

				<div class="panel-body">

			<form method="POST" action="<?php echo e(url('/update')); ?>">
				<?php echo e(csrf_field()); ?>

				<input type="hidden" name="id" value="<?php echo e($id); ?>">
				<table>
					<tr>
						<td>Meno</td>
						<td><input type="text" name="name" value="<?php echo e(Auth::user()->name); ?>"></td>
					</tr>
					<tr>
						<td>Email</td>
						<td><input type="text" name="email" value="<?php echo e(Auth::user()->email); ?>"></td>
					</tr>
					<tr>
						<td>Číslo</td>
						<td><input type="text" name="phone" value="<?php echo e(Auth::user()->phone); ?>"></td>
					</tr>
					<tr>
						<td><input type="submit" name="Submit" value="Zmeniť"></td>
					</tr>
				</table>
			</form>
						</div>
			</div>
		</div>
	</div>


				

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admincalendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>