  

  <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
  <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="//code.jquery.com/jquery-1.11.1.min.js"></script>
  <!------ Include the above in your HEAD tag ---------->

  <link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.6.0/css/font-awesome.min.css" rel="stylesheet">

  <?php $__env->startSection('style'); ?>
  <link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.css"/>
  <?php $__env->stopSection(); ?>

  <?php $__env->startSection('content'); ?>

  <div class="container">
    <div class="panel panel-primary">
      <div class="panel-heading"></div>
      <div class="panel-body"> 
        <div class="row">
          <div class="col-md-12 col-md-offset-1">
            <?php if($movies != '[]'): ?>
              <div class="top-margin-header panel heading"><h1 class="h1-bigger text-center text-white">Dňa <?php echo e(date("d.m", strtotime("+$day day"))); ?> hráme</h1></div>
            <?php else: ?>
              <div class="top-margin-header panel heading"><h1 class="h1-bigger text-center text-white">Na dnešný deň pripravujeme program</h1></div>
              <div class="col-lg-12 col-md-12 col-sm-12">
                <article class="card">
                  <div class="card-block">
                    <div class="img-card">
                      <img src="/images/hall.jpg" alt="Movie" class="w-100" />
                    </div>
                  </div>
                </article>
                <br>
              </div>
            <?php endif; ?>
            <div class="row">
		          <?php $__currentLoopData = $movies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $movie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		            <div class="col-lg-4 col-md-5 col-sm-6">
			            <article class="card">
				            <h2 class="bot-no-margin card-title p-3 mb-2 bg-dark text-white text-center"><?php echo e($movie->title); ?></h2>
				            <div class="card-block">
				              <div class="img-card">
					              <img src="<?php echo e($movie->image); ?>" alt="Movie" class="w-100" />
				              </div>
                      <h5 class="bot-no-margin p-3 mb-2 bg-dark text-white tagline card-text text-xs-center text-center">Dĺžka filmu: <?php echo e($movie->length); ?> minút<br> Žáner: <?php echo e($movie->genre); ?><br> Jazyk: <?php echo e($movie->language); ?></h5>
                      <textarea class="bot-no-margin form-control mb-2 mr-sm-2" rows="6" cols="20" name="info" readonly><?php echo e($movie->info); ?></textarea>

                      <?php if($movie->time < date("H:i", strtotime("+130 minutes")) and $movie->date == date("Y-m-d", strtotime("+0 days"))): ?>
                        <a href="<?php echo e(url('film',$movie->id)); ?>" class="not-clickable btn btn-danger btn-block"><i class=""></i> <?php echo e(date("H:i", strtotime($movie->time))); ?></a>
                      <?php else: ?>
                        <a href="<?php echo e(url('film',$movie->id)); ?>" class="btn btn-success btn-block"><i class="fa fa-eye"></i> <?php echo e(date("H:i", strtotime($movie->time))); ?></a>
                      <?php endif; ?>
				            </div>
			            </article>
                  <br>
		            </div>
		          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>  

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.movie', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>