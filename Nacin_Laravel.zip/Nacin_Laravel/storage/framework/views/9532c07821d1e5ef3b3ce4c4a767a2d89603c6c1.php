<?php $__env->startSection('content'); ?>

 	<div class="container">
    	<div class="panel panel-primary">
       		<div class="panel-heading"></div>
          	<div class="panel-body"> 
				<div class="row">
					<div class="col-md-10 col-xs-12 col-md-offset-1">
						<div class="panel heading"><h4>Zoznam smien</h4></div>
						<div class="row">
							<div class="col-md-3">
								Mená: 
								<a href="/admin/eventslistrequest/?name=asc">Vzostupne</a> |
								<a href="/admin/eventslistrequest/?name=desc">Zostupne</a>
							</div>
							<div class="col-md-3">
								Dátum: 
								<a href="/admin/eventslistrequest/?event_time=asc">Vzostupne</a> |
								<a href="/admin/eventslistrequest/?event_time=desc">Zostupne</a> |
								<a href="/admin/eventslistrequest/">Obnoviť</a>
							</div>
							<ul class="navbar-nav ml-auto">
								<div class="col-md-12">

									
                        			        <form action="/admin/eventslistrequest/search" method="POST" role="search">
    											<?php echo e(csrf_field()); ?>

			    								<div class="input-group">
       												<input type="text" class="form-control" name="q"
            										placeholder="Vyhľadať zamestnanca"> <span class="input-group-btn">
            										<button type="submit" class="btn btn-default">
                									<span class="glyphicon glyphicon-search"></span></button></span>
	    										</div>
											</form>
                                			<form action="/admin/eventslistrequest/search" method="POST" role="search">
		    									<?php echo e(csrf_field()); ?>

			    								<div class="input-group">
        											<input type="date" class="form-control" name="q"
            										placeholder="Vyhľadať dátum smeny"> <span class="input-group-btn">
            										<button type="submit" class="btn btn-default">
                									<span class="glyphicon glyphicon-search"></span></button></span>
    											</div>
											</form>
                            			
								</div>
							</ul>
						</div>
						<?php if(isset($events)): ?>
						<div class="panel-body">
							<div class="col-md-12 col-xs-12 scroll">
								<table class="table">
  									<thead>
  										<h3>Hlási sa</h3>
    									<tr>
      										<th scope="col"></th>
      										<th scope="col">Zamestnanec</th>
      										<th scope="col">Deň</th>
    									</tr>
  									</thead>
  									<tbody>
  										<?php $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    										<tr>
      											<th scope="row"></th>
      											<?php if(strpos($event->event_name, ' --- ') !== false): ?> 
													<td><?php echo e($event->event_name); ?></td>
													<td><?php echo e(date("d.m.Y", strtotime($event->start_date))); ?></td>
													<td><a href="/admin/deleteevents/<?php echo e($event->id); ?>'" onclick="return confirm('Skutočne chcete tento záznam vymazať?');">Vymazať</a></td>
												<?php endif; ?>
    										</tr>
    									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  									</tbody>
								</table>
							</div>
							<div class="col-md-12 col-xs-12 text-center">
								<?php echo $events->render(); ?>

							</div>
						</div>
						<?php else: ?>
						<div class="panel-body">
							<div class="col-md-12 col-xs-12 text-center">
								<?php if(Session::has('error')): ?>
                    				<div class="alert alert-danger"><h4><?php echo e(Session::get('error')); ?></h4></div>
                    			<?php endif; ?>
							</div>
						</div>
						<?php endif; ?>
					</div>	
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admincalendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>