<?php $__env->startSection('content'); ?>
	<div class="container">
  		<div class="panel panel-primary">
   	 		<div class="panel-heading"></div>
    		<div class="panel-body"> 
      			<div class="row">
       			 	<div class="col-md-4 col-xs-10 col-md-offset-1 col-xs-offset-1">
          				<div class="panel heading"><h4>Úprava informácií</h4></div>
            			<div class="row">  
							<form method="POST" action="<?php echo e(url('/admin/update')); ?>">
								<?php echo e(csrf_field()); ?>

								<input type="hidden" name="id" value="<?php echo e($id); ?>">
								<table>
									<tr>
										<td><strong>Meno</strong></td>
										<td><input type="text" class="form-control mb-2 mr-sm-2" name="name" value="<?php echo e($user->name); ?>"></td>
									</tr>
									<tr>
										<td><strong>Email</strong></td>
										<td><input type="text" class="form-control mb-2 mr-sm-2" name="email" value="<?php echo e($user->email); ?>"></td>
									</tr>
									<tr>
										<td><strong>Číslo</strong></td>
										<td><input type="text" class="form-control mb-2 mr-sm-2" name="phone" value="<?php echo e($user->phone); ?>"></td>
									</tr>
									<tr>
										<td><strong>Floor</strong></td>
										<td>
											<select name="floor" class="form-control mb-2 mr-sm-2" value="<?php echo e($user->floor); ?>">
												<option value="1">Áno</option>
												<option value="0">Nie</option>
											</select>
										</td>
									</tr>
									<tr>
										<td><strong>Buffet</strong></td>
										<td>
											<select name="buffet" class="form-control mb-2 mr-sm-2" value="<?php echo e($user->buffet); ?> ">
												<option value="1">Áno</option>
												<option value="0">Nie</option>
											</select>
										</td>
									</tr>
									<tr>
										<td><strong>Pokladňa</strong></td>
										<td>
											<select name="pokladna" class="form-control mb-2 mr-sm-2" value="<?php echo e($user->pokladna); ?>">
												<option value="1">Áno</option>
												<option value="0">Nie</option>
											</select>
										</td>
									</tr>
									<tr>
										<td><input type="submit" class="btn btn-primary mb-2" name="Submit" value="Zmeniť"></td>
									</tr>
								</table>
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admincalendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>