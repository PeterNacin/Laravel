<div class="col-xs-3 col-sm-3 col-md-3">
                        <div class="form-group">
                            <?php echo Form::label('event_name','Event Name:'); ?>

                            <div class="">
                              <label class="sr-only" for="inlineFormInputName2">Name</label>
                                <select class="form-control mb-2 mr-sm-2" id="inlineFormInputName2" name="event_name">
                                  <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="otvarac"><?php echo e($user->name); ?></option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                              <?php echo $errors->first('event_name', '<p class="alert alert-danger">:message</p>'); ?>

                            </div>
                        </div>
                      </div>
