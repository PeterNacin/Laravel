	

	<?php $__env->startSection('style'); ?>
	<link rel="stylesheet" type="text/css" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/2.2.7/fullcalendar.min.css"/>
	<?php $__env->stopSection(); ?>

	<?php $__env->startSection('content'); ?>
	<div class="container">
  		<div class="panel panel-primary">
   	 		<div class="panel-heading"></div>
    		<div class="panel-body"> 
      			<div class="row">
       			 	<div class="col-md-10 col-md-offset-1">
          				<div class="panel heading"><h4>Profil manažéra</h4>
          					<h5><a href="<?php echo e(url('admin/editself',Auth::user()->id)); ?>">Upraviť</a></h5>
          					<h5><a href="<?php echo e(url('admin/changepassword')); ?>">Zmena hesla</a></h5>
          				</div>
            			<div class="row">
            				<div class="col-md-4">
							<table>
								<tr>
									<td>Meno: <strong><?php echo e(Auth::user()->name); ?></strong></td>
								</tr>
								<tr>
									<td>Email: <strong><?php echo e(Auth::user()->email); ?></strong></td>
								</tr>
								<tr>
									<td>Číslo: <strong><?php echo e(Auth::user()->phone); ?></strong></td>
								</tr>
							</table>
						</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	


	<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admincalendar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>