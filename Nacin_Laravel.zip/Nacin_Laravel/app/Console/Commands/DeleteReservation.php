<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

use Carbon;

class DeleteReservation extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'command:deletereservation';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */

    /* Zrusenie vsetkych rezervacii 10 minut pred filmom */

    public function handle()
    {

        $dates = DB::table('show')->where('date', '=', date('Y-m-d'))->where('time', '=', date("H:i",strtotime(date("H:i")." +130 minutes")))->get();

        foreach($dates as $date){

            $seats = DB::table('seat')->where('show_id',$date->id)->where('taken','1')->get();

            foreach($seats as $seat){

            
                $reservations = DB::table('reservation')->where('id',$seat->reservation_id)->where('paid','0')->get();

                foreach($reservations as $reservation){

                    $data = array('reservation_id'=>$reservation->id,'row'=>$seat->row,'seat'=>$seat->seat,'taken'=>'0','movie_id'=>$date->id);
                    
                    DB::table('seat')->where('id',$seat->id)->update($data);

                    $data = array('email'=>$reservation->email,'paid'=>$reservation->paid,'expired'=>'1');

                    DB::table('reservation')->where('id',$reservation->id)->update($data);

                }
            }
        }
    }
}
/*
$data = array('email'=>$request->input('nameDisplay'),'paid'=>'0', 'created_at'=>date('Y/m/d H:i:s',strtotime(date('Y/m/d H:i:s')." +60 minutes")));

        DB::table('reservation')->insert($data);

        $reservations = DB::table('reservation')->where('email',$request->input('nameDisplay'))->where('paid','0')->where('created_at',date('Y/m/d H:i:s',strtotime(date('Y/m/d H:i:s')." +60 minutes")))->get();
   
        for ($i = 0; $i <= $comma_count; $i++){
            

            $mix = explode('/',$res[$i]); 
            
            $row = null;
            $place = null;
            $row = $mix[0];
            $place = $mix[1];

            $seats = DB::table('seat')->where('seat',$place)->where('row',$row)->where('movie_id',$id)->get();

            foreach($seats as $seat){
                foreach($reservations as $reservation){

                    $data = array('reservation_id'=>$reservation->id,'row'=>$row,'seat'=>$place,'taken'=>'1','movie_id'=>$id, 'created_at'=>date('Y/m/d H:i:s',strtotime(date('Y/m/d H:i:s')." +60 minutes")));

                    DB::table('seat')->where('id',$seat->id)->update($data);*/

    

    

    