<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;

/* Controller pre zobrazenie filmov a noviniek */

class MovieController extends Controller
{

    /* Zobrazenie stranky s filmami */ 

    public function index()
    {

        if(request()->has('day')){
            if(request('day') == 0){

                $movies = DB::table('movies')->where('active','=','1')
                ->join('show','show.movie_id','=', 'movies.id')
                ->where('show.date','=', date("Y-m-d", strtotime("+0 day")))
                ->select('movies.title','movies.length','movies.genre','movies.language','movies.image','movies.info','show.date','show.time','show.id')
                ->get();

                //return $movies;

                return view('movies')->with('movies', $movies)
                ->with('day','0');

            }else if(request('day') == 1){
                $movies = DB::table('movies')->where('active','=','1')
                ->join('show','show.movie_id','=', 'movies.id')
                ->where('show.date','=', date("Y-m-d", strtotime("+1 day")))
                ->select('movies.id','movies.title','movies.length','movies.genre','movies.language','movies.image','movies.info','show.date','show.time','show.id')
                ->get();

                return view('movies')->with('movies', $movies)
                ->with('day','1');
            }else if(request('day') == 2){
                $movies = DB::table('movies')->where('active','=','1')
                ->join('show','show.movie_id','=', 'movies.id')
                ->where('show.date','=', date("Y-m-d", strtotime("+2 day")))
                ->select('movies.id','movies.title','movies.length','movies.genre','movies.language','movies.image','movies.info','show.date','show.time','show.id')
                ->get();

                return view('movies')->with('movies', $movies)
                ->with('day','2');
            }
            else if(request('day') == 3){
                $movies = DB::table('movies')->where('active','=','1')
                ->join('show','show.movie_id','=', 'movies.id')
                ->where('show.date','=', date("Y-m-d", strtotime("+3 day")))
                ->select('movies.id','movies.title','movies.length','movies.genre','movies.language','movies.image','movies.info','show.date','show.time','show.id')
                ->get();

                return view('movies')->with('movies', $movies)
                ->with('day','3');
            }
            else if(request('day') == 4){
                $movies = DB::table('movies')->where('active','=','1')
                ->join('show','show.movie_id','=', 'movies.id')
                ->where('show.date','=', date("Y-m-d", strtotime("+4 day")))
                ->select('movies.id','movies.title','movies.length','movies.genre','movies.language','movies.image','movies.info','show.date','show.time','show.id')
                ->get();

                return view('movies')->with('movies', $movies)
                ->with('day','4');
            }
            else if(request('day') == 5){
                $movies = DB::table('movies')->where('active','=','1')
                ->join('show','show.movie_id','=', 'movies.id')
                ->where('show.date','=', date("Y-m-d", strtotime("+5 day")))
                ->select('movies.id','movies.title','movies.length','movies.genre','movies.language','movies.image','movies.info','show.date','show.time','show.id')
                ->get();

                return view('movies')->with('movies', $movies)
                ->with('day','5');
            }
            else if(request('day') == 6){
                $movies = DB::table('movies')->where('active','=','1')
                ->join('show','show.movie_id','=', 'movies.id')
                ->where('show.date','=', date("Y-m-d", strtotime("+6 day")))
                ->select('movies.id','movies.title','movies.length','movies.genre','movies.language','movies.image','movies.info','show.date','show.time','show.id')
                ->get();

                return view('movies')->with('movies', $movies)
                ->with('day','6');
            }else{
                $movies = DB::table('movies')->where('active','=','1')
                ->join('show','show.movie_id','=', 'movies.id')
                ->where('show.date','=', date("Y-m-d", strtotime("+0 day")))
                ->select('movies.id','movies.title','movies.length','movies.genre','movies.language','movies.image','movies.info','show.date','show.time','show.id')
                ->get();  
            }
        }else{
            $movies = DB::table('movies')->where('active','=','1')
                ->join('show','show.movie_id','=', 'movies.id')
                ->where('show.date','=', date("Y-m-d", strtotime("+0 day")))
                ->select('movies.id','movies.title','movies.length','movies.genre','movies.language','movies.image','movies.info','show.date','show.time','show.id')
                ->get();
                
        }

        return view('movies')->with('movies', $movies)
                ->with('day','0');
    }

    /* Zobrazenie stranky s novinkami */

    public function news()
    {
        $movies = DB::table('movies')->where('active','=','2')->get();

        $movies = DB::table('movies')->where('active','=','2')
                ->join('show','show.movie_id','=', 'movies.id')
                ->select('movies.id','movies.title','movies.length','movies.genre','movies.language','movies.image','movies.info','show.date')
                ->get();

        return view('news')->with('movies', $movies);
    }
}
