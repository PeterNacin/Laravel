<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input as Input;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\User;
use Auth;


/* Controller funkcii pre uzivatelov */

class UserController extends Controller
{
    /* Pristup pre uzivatelov */ 

    public function __construct()
    {
        $this->middleware('auth');
    }

    /* Zobrazenie zoznamu smien */

    public function eventslist()
    {
        if(request()->has('event_time')){
            $events = DB::table('events')->orderBy('start_date',request('event_time'))->paginate(10);
        }
        else if(request()->has('name')){
            $events = DB::table('events')->orderBy('event_name',request('name'))->paginate(10);
        }
        else{
            $events = DB::table('events')->paginate(10);
        }
        return view('/eventslist',['events' => $events]);
    }

    /* Zobrazenie stranky pre zmeny hesla uzivatela */

    public function changepass(){
        return view('auth.change_password');
    }

    /* Zmena hesla pre uzivatela */

    public function changepassword(){
        $User = User::find(Auth::user()->id);

        if(Hash::check(Input::get('passwordold'),$User['password']) && Input::get('password') == Input::get('password_confirmation')){
            $User->password = Hash::make(Input::get('password'));
            $User->save();

            \Session::flash('success','Úspešne ste zmenili heslo.');
            return Redirect::to('/changepassword');
        }else{
            \Session::flash('error','Heslo nebolo zmenené.');
            return Redirect::to('/changepassword');
        }
    }

    /* Zobrazenie stranky pre upravu informacii pre uzivatela */

    public function edit($id)
    {
        $user =  DB::table('users')->where('id',$id);
        return view('/editself',compact('user'))->with('id',$id);
    }

    /* Zmena informacii ako uzivatel */

    public function updateself(Request $request){

        $users = DB::table('users')->where('id',$request->id)->get();

        
        foreach ($users as $user) {

            $events = DB::table('events')->where('event_name', 'like','%' .$user->name. '%')->get();

            foreach ($events as $event) {     

                $substring = substr($event->event_name, 0, strpos($event->event_name, ' '));

                $count_change = strlen($substring); // 8
                $count_event = strlen($event->event_name);  //21

                $change = substr($event->event_name, $count_change, $count_event);  // 8 - 21
                $result = $request->name . $change;

                $data = ['event_name'=>$result];
                $events = DB::table('events')->where('id',$event->id)->update($data);

                $data = ['name'=>$request->name,
                 'email'=>$request->email,
                 'phone'=>$request->phone];
                DB::table('users')->where('id',$request->id)->update($data);

                $result = null;
                $substring = null;
                $change = null;
                $count_event = null;
                $count_change = null;
                $events = null;

            }

        }
        return Redirect::to('/home');
    }

}
