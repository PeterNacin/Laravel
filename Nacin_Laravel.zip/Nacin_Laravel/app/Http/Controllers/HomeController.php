<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Input as Input;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\User;
use Auth;

/* Controller pristupu pre uzivatelov */

class HomeController extends Controller
{
    /* Pristup pre uzivatelov */

    public function __construct()
    {
        $this->middleware('auth');
    }

    /* Uvodna stranka pre uzivatela */
    public function index()
    {
        $users = DB::table('users')->get();

        return view('home', ['users' => $users]);
    }

    /* Informacna stranka pre uzivatela */

    public function contact()
    {
        $admins = DB::table('admins')->get();

        return view('contact', ['admins' => $admins]);
    }

    /* Zobrazenie vsetkych smien daneho uzivatela */

    public function eventslist()
    {

        if(request()->has('event_time')){

            $events_A = DB::table('events')->where('event_name', 'like','%' .Auth::user()->name. '%')
                                            ->where('confirm', '0')
                                            ->orderBy('start_date',request('event_time'))
                                            ->paginate(15, ['*'], 'requested')
                                            ->appends('event_time', request('event_time'))
                                            ->appends('requested', request('requested'))
                                            ->appends('confirmed', request('confirmed'));

            $events_B = DB::table('events')->where('event_name', 'like','%' .Auth::user()->name. '%')
                                            ->where('confirm', '1')
                                            ->orderBy('start_date',request('event_time'))
                                            ->paginate(15, ['*'], 'confirmed')
                                            ->appends('event_time', request('event_time'))
                                            ->appends('requested', request('requested'))
                                            ->appends('confirmed', request('confirmed'));
        }
        else{
            $events_A = DB::table('events')->where('event_name', 'like','%' .Auth::user()->name. '%')
                                            ->where('confirm', '0')
                                            ->paginate(15, ['*'], 'requested')
                                            ->appends('requested', request('requested'))
                                            ->appends('confirmed', request('confirmed'));

            $events_B = DB::table('events')->where('event_name', 'like','%' .Auth::user()->name. '%')
                                            ->where('confirm', '1')
                                            ->paginate(15, ['*'], 'confirmed')
                                            ->appends('confirmed', request('confirmed'))
                                            ->appends('requested', request('requested'));

        }
        return view('/eventslist',['events_A' => $events_A],['events_B' => $events_B]);
    }

}
