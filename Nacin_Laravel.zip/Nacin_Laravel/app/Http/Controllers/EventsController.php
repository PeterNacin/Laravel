<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use App\Http\Controllers\Controller;
use Auth;
use Validator;
use App\Events;
use App\User;
use Carbon\Carbon;

use Calendar;

/* Controller kalendaru pre uzivatelov */

class EventsController extends Controller
{
    /* Pristup pre uzivatelov */ 

    public function __construct()
    {
        $this->middleware('auth');
    }

    /* Nacitanie stranky + vybratie informacii pre zobrazenie kalendaru */

    public function index(){
    	$events = Events::get();
    	$event_list = [];
    	foreach ($events as $key => $event) {
            if (strpos($event->event_name, Auth::user()->name) !== false) {
                if (strpos($event->event_name, '-') !== false){
                    $color = '#ff6666'; 
                }
                else if (strpos($event->event_name, '=') !== false){
                    $color = '#98fb98'; 
                }
            }
            else  {
                $color = 'lightgrey';
            }
            if(request()->has('my') and (request('my') == 1)){
                if (strpos($event->event_name, Auth::user()->name) !== false) {
                $event_list[] = Calendar::event(
                    $event->event_name,
                    false,
                    new \DateTime($event->start_date),
                    new \DateTime($event->end_date),
                    0,
                    ['color' => $color]);
                }
            }else{
                $event_list[] = Calendar::event(
                    $event->event_name,
                    false,
                    new \DateTime($event->start_date),
                    new \DateTime($event->end_date),
                    0,
                    ['color' => $color]);
            }
        }

    	$calendar_details = Calendar::addEvents($event_list)->setOptions(['firstDay' => 1,'monthNames'=>['Január','Február','Marec','Apríl','Máj','Jún','Júl','August','September','Október','November','December'],'monthNamesShort'=>['Jan','Feb','Mar','Apr','Máj','Jún','Júl','Aug','Sep','Okt','Nov','Dec'],'dayNames'=>['Pondelok','Utorok','Streda','Štvrtok','Piatok','Sobota','Nedeľa'],'dayNamesShort'=>['Neď','Pon','Uto','Str','Štv','Pia','Sob'],'header' => ['left' => 'prev,next today','center' => 'title','right' => 'month,agendaWeek,agendaDay,listWeek'],'buttonText'=>['today'=>'Dnes','month'=>'Mesiac','agendaWeek'=>'Týždeň','agendaDay'=>'Deň','listWeek'=>'Týždenný zoznam'],'minTime'=>'10:00:00','allDaySlot'=>false,'listWeekFormat'=>true,'displayEventTime'=>false])/*->setCallbacks(['eventClick' => 'function() {window.open("/eventslist");}'])*/;
 
        return view('/events', compact('calendar_details') );
    }

    /* Nahlasenie smeny a pridanie do databazy */

    public function addEvent(Request $request){
    	$validator = Validator::make($request->all(), [
    		'event_name' => 'required',
    		'start_date' => 'required',
    	]);

    	if($validator->fails()){
    		\Session::flash('warning','Vyplňte všetko požadované.');
    		return Redirect::to('/events')->withInput()->withErrors($validator);
    	}

    	$event = New Events;
    	$event->event_name = Auth::user()->name . ' --- ' . $request['event_name'];
    	$event->start_date = $request['start_date'] . 'T00:00';
    	$event->end_date = $request['start_date'] . 'T00:00';
        $event->confirm = '0';
    	$event->save();

    	\Session::flash('success','Úspešne ste sa prihlásili na smenu.');
    	return Redirect::to('/events');
    }

    /* Zobrazenie konkretneho eventu pre upravu */

    public function editevents($id)
    {
        $event =  DB::table('events')->where('id',$id)->first();
        $users = DB::table('users')->get();
        return view('editevents',compact('event'),['users' => $users])->with('id',$id);
    }

    /* Upravenie eventu */

    public function updateevents(Request $request){
        $data = ['event_name'=>Auth::user()->name . ' --- ' . $request->position,
                 'start_date'=>$request['start_date'] . 'T00:00',
                 'end_date'=>$request['start_date'] . 'T00:00'];
        DB::table('events')->where('id',$request->id)->update($data);
        return Redirect::to('eventslist');
    }

     /* Zmazanie eventu */

    public function deleteevents($id){
        DB::table('events')->where('id',$id)->delete();
        return Redirect::to('eventslist');
    }
}



