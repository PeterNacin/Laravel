<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Input as Input;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller;
use Auth;
use Validator;
use App\Events;
use App\User;
use App\SearchDetails;
use Carbon\Carbon;

use Calendar;

/* Controller kalendaru pre manazerov */

class EventsController extends Controller
{
    /* Pristup iba pod manazerom */
    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    /* Nacitanie stranky + vybratie informacii pre zobrazenie kalendaru */

    public function index(){
    	$events = Events::get();
    	$event_list = [];
    	foreach ($events as $key => $event) {
            if (strpos($event->event_name, '> buffet') !== false) {
                $color = '#00ff00'; 
            }
            else  if(strpos($event->event_name, '> výpomoc buffet') !== false){
                $color = 'lightgreen';
            }
            else  if(strpos($event->event_name, '> pokladňa') !== false){
                $color = 'yellow';
            }
            else  if(strpos($event->event_name, '> otvárač') !== false){
                $color = '#ff6666';
            }
            else  if(strpos($event->event_name, '> zatvárač') !== false){
                $color = 'orange';
            }
            else  if(strpos($event->event_name, '> výpomoc floor') !== false){
                $color = 'violet';
            }
            else  {
                $color = 'lightgrey';
            }
            if(request()->has('confirm') and (request('confirm') == 1)){
                if (strpos($event->event_name, '=') !== false) {
                $event_list[] = Calendar::event(
                    $event->event_name,
                    false,
                    new \DateTime($event->start_date),
                    new \DateTime($event->end_date),
                    0,
                    ['color' => $color]);
                }
            }else if(request()->has('confirm') and (request('confirm') == 0)){
                if (strpos($event->event_name, '-') !== false) {
    		    $event_list[] = Calendar::event(
                    $event->event_name,
                    false,
                    new \DateTime($event->start_date),
                    new \DateTime($event->end_date),
                    0,
                    ['color' => $color]);
                }
            }else{
                $event_list[] = Calendar::event(
                    $event->event_name,
                    false,
                    new \DateTime($event->start_date),
                    new \DateTime($event->end_date),
                    0,
                    ['color' => $color]);
            }
    	}
        
    	$calendar_details = Calendar::addEvents($event_list)->setOptions(['firstDay' => 1,'monthNames'=>['Január','Február','Marec','Apríl','Máj','Jún','Júl','August','September','Október','November','December'],'monthNamesShort'=>['Jan','Feb','Mar','Apr','Máj','Jún','Júl','Aug','Sep','Okt','Nov','Dec'],'dayNames'=>['Pondelok','Utorok','Streda','Štvrtok','Piatok','Sobota','Nedeľa'],'dayNamesShort'=>['Neď','Pon','Uto','Str','Štv','Pia','Sob'],'header' => ['left' => 'prev,next today','center' => 'title','right' => 'month,agendaWeek,agendaDay,listWeek'],'buttonText'=>['today'=>'Dnes','month'=>'Mesiac','agendaWeek'=>'Týždeň','agendaDay'=>'Deň','listWeek'=>'Týždenný zoznam'],'minTime'=>'10:00:00','allDaySlot'=>false,'listWeekFormat'=>true,'displayEventTime'=>false])/*->setCallbacks(['eventClick' => 'function() {window.open("/admin/eventslist");}'])*/;

        $users = DB::table('users')->get();
 
        return view('/admin/events', compact('calendar_details'),['users' => $users] );
    }

    /* Potrdenie smeny a pridanie do databazy */

    public function addEvent(Request $request){
    	$validator = Validator::make($request->all(), [
    		'event_name' => 'required',
            'position' => 'required',
    		'start_date' => 'required',
            'start_time' => 'required',
            'end_time' => 'required',
    	]);

    	if($validator->fails()){
    		\Session::flash('warning','Vyplňte všetko požadované.');
    		return Redirect::to('/admin/events')->withInput()->withErrors($validator);
    	}

    	$event = New Events;
    	$event->event_name = $request['event_name'] . ' ==> ' . $request['position'];
    	$event->start_date = $request['start_date'].' '.$request['start_time'];
    	$event->end_date = $request['start_date'].' '.$request['end_time'];
        $event->confirm = '1';
    	$event->save();

    	\Session::flash('success','Smena potvrdená.');
    	return Redirect::to('/admin/events');
    }

    /* Zobrazenie konkretneho eventu pre upravu */

    public function editevents($id)
    {
        $event =  DB::table('events')->where('id',$id)->first();
        $users = DB::table('users')->get();
        return view('admin.editevents',compact('event'),['users' => $users])->with('id',$id);
    }

    /* Upravenie eventu */

    public function updateevents(Request $request){
        $data = ['event_name'=>$request->event_name . ' ==> ' . $request->position,
                 'start_date'=>$request->start_date.' '.$request->start_time,
                 'end_date'=>$request->start_date.' '.$request->end_time];
        DB::table('events')->where('id',$request->id)->update($data);
        return Redirect::to('admin/eventslistconfirm');
    }

    /* Delete eventu */

    public function deleteevents($id){
        DB::table('events')->where('id',$id)->delete();
        return Redirect::to('admin/eventslistconfirm');
    }

    /* Vyhladanie eventu + pagination */

    public function eventsearchrequest(){
         if(request()->has('event_time')){
            $events = DB::table('events')->where('confirm', '0')
                                        ->orderBy('start_date',request('event_time'))
                                        ->paginate(15)
                                        ->appends('event_time', request('event_time'));
        }
        else if(request()->has('name')){
            $events = DB::table('events')->where('confirm', '0')
                                        ->orderBy('event_name',request('name'))
                                        ->paginate(15)
                                        ->appends('name', request('name'));
        }
        else{
            $events = DB::table('events')->where('confirm', '0')->paginate(15);
        }


        return view('/admin/eventslistrequest')->with('events', $events);
    }

    public function searchrequest(){
        $q = Input::get('q');
        
        if (false === strtotime($q)) {
            if($q != ""){
                $events = DB::table('events')->where('confirm', '0')
                        ->where('event_name', 'like', '%' .$q. '%')
                        ->paginate(15)
                        ->setpath('');

                $events->appends(array(
                    'q' => Input::get('q'),
                ));

                if(count($events) > 0){
                    return view('/admin/eventslistrequest')->with('events', $events);
                }   

                \Session::flash('error','Neboli nájdene žiadne výsledky.');
                return view('/admin/eventslistrequest');
            }

        }else{
            if($q != ""){
                $events = DB::table('events')->where('confirm', '0')
                        ->where('start_date', 'like', '%' .$q. '%')
                        ->paginate(15)
                        ->setpath('');

                $events->appends(array(
                    'q' => Input::get('q'),
                ));

                if(count($events) > 0){
                    return view('/admin/eventslistrequest')->with('events', $events);
                } 

                \Session::flash('error','Neboli nájdene žiadne výsledky.');
                return view('/admin/eventslistrequest');
            }

        }
    }

    public function eventsearchconfirm(){

        if(request()->has('event_time')){
            $events = DB::table('events')->where('confirm', '1')
                                        ->where('start_date',request('event_time'))
                                        ->paginate(15)
                                        ->appends('event_time', request('event_time'));
        }
        else if(request()->has('name')){
            $events = DB::table('events')->where('confirm', '1')
                                        ->where('event_name',request('name'))
                                        ->paginate(15)
                                        ->appends('name', request('name'));
        }
        else{
            $events = DB::table('events')->where('confirm', '1')->paginate(15);
        }

        return view('/admin/eventslistconfirm')->with('events', $events);
    }

    public function searchconfirm(){
        $q = Input::get('q');

        if (false === strtotime($q)) {
            if($q != ""){
                $events = DB::table('events')->where('confirm', '1')
                        ->where('event_name', 'like', '%' .$q. '%')
                        ->paginate(15)
                        ->setpath('');

                $events->appends(array(
                    'q' => Input::get('q'),
                ));

                if(count($events) > 0){
                    return view('/admin/eventslistconfirm')->with('events', $events);
                }   

                \Session::flash('error','Neboli nájdene žiadne výsledky.');
                return view('/admin/eventslistconfirm');
            }

        }else{
            if($q != ""){
                $events = DB::table('events')->where('confirm', '1')
                        ->where('start_date', 'like', '%' .$q. '%')
                        ->paginate(15)
                        ->setpath('');

                $events->appends(array(
                    'q' => Input::get('q'),
                ));

                if(count($events) > 0){
                    return view('/admin/eventslistconfirm')->with('events', $events);
                } 

                \Session::flash('error','Neboli nájdene žiadne výsledky.');
                return view('/admin/eventslistconfirm');
            }

        }

    }


}
