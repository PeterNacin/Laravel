<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Support\Facades\Input as Input;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Hash;
use App\Http\Controllers\Controller;
use Auth;
use Validator;
use App\Events;
use App\User;
use Carbon\Carbon;

use Calendar;

/* Controller filmov pre manazerov */

class MovieController extends Controller
{
    /* Pristup len pre manazerov */ 
	public function __construct()
    {
        $this->middleware('auth:admin');
    }

    /* Zobrazenie konkretneho filmu pre upravu */

    public function editmovies($id)
    {
        $movie =  DB::table('movies')->where('id',$id)->first();
        
        return view('admin.editmovies',compact('movie'))->with('id',$id);
    }

    /* Uprava filmov */

    public function updatemovies(Request $request){

        $data = ['title'=>$request->title,
                 'active'=>$request->active,
                 'length'=>$request->length,
                 'language'=>$request->language,
                 'genre'=>$request->genre,
                 'info'=>$request->info,
                 'image'=>'/images/' . $request->image];
        DB::table('movies')->where('id',$request->id)->update($data);
        return Redirect::to('admin/movielist');
    }

    /* Delete filmov */

    public function deletemovie($id){
        DB::table('movies')->where('id',$id)->delete();
        DB::table('show')->where('movie_id',$id)->delete();
        return Redirect::to('admin/movielist');
    }

    /* Zobrazenie stranky pridania filmov */

    

    public function insertshow(Request $request){

        $date = $request->input('date');
        $time = $request->input('time');
        $hall = $request->input('hall');

        if($hall == 'new' and $time == 'new'){
            $time = '00:00';
            //return $time;
            //nevytvori sa sala

        }

        $data = array('date'=>$date,'time'=>$time,'movie_id'=>$request->id);

        DB::table('show')->insert($data);


        $new_id = DB::table('show')->orderBy('id', 'desc')->first();
        $new_id = $new_id->id;

        //   R x S
        // A 13x21
        // B 9x20
        // C 8x13
        // D 8x12

        if($hall == 'A'){
            for ($i = 1; $i <= 13; $i++) {
                for ($j = 1; $j <= 21; $j++) {
                $data = array('row'=>$i,'seat'=>$j,'reservation_id'=>'0','show_id'=>$new_id,'hall'=>$request->hall);

                DB::table('seat')->insert($data);
            
                }
            }
        }else if($hall == 'B'){
            for ($i = 1; $i <= 9; $i++) {
                for ($j = 1; $j <= 20; $j++) {
                $data = array('row'=>$i,'seat'=>$j,'reservation_id'=>'0','show_id'=>$new_id,'hall'=>$request->hall);

                DB::table('seat')->insert($data);
            
            }
        }
        }else if($hall == 'C'){
            for ($i = 1; $i <= 8; $i++) {
                for ($j = 1; $j <= 13; $j++) {
                $data = array('row'=>$i,'seat'=>$j,'reservation_id'=>'0','show_id'=>$new_id,'hall'=>$request->hall);

                DB::table('seat')->insert($data);
            
                }
            }
        }
        else if($hall == 'D'){
            for ($i = 1; $i <= 8; $i++) {
                for ($j = 1; $j <= 12; $j++) {
                $data = array('row'=>$i,'seat'=>$j,'reservation_id'=>'0','show_id'=>$new_id,'hall'=>$request->hall);

                DB::table('seat')->insert($data);
            
                }
            }
        }
        
        return Redirect::to('admin/movielist');

    }

    /* Pridanie filmov */

    public function insertmovie(Request $request){

        $title = $request->input('title');
        $active = $request->input('active');
        $length = $request->input('length');
        $genre = $request->input('genre');
        $language = $request->input('language');
        $info = $request->input('info');
        $image = '/images/' . $request->input('image');

        $data = array('title'=>$title,'active'=>$active,'length'=>$length,'genre'=>$genre,'language'=>$language,'info'=>$info,'image'=>$image);

        DB::table('movies')->insert($data);
        
        return Redirect::to('admin/movielist');
    }

    /* Vyhladanie filmov */

    public function movielist(){

        if(request()->has('active')){
            $movies = DB::table('movies')->where('active', request('active'))
                                        ->paginate(15)
                                        ->appends('page', request('page'))
                                        ->appends('active', request('active'))
                                        ->appends('date', request('date'));
        }
        else if(request()->has('date')){

            $movies = DB::table('movies')->orderBy('date',request('date'))
                                        ->paginate(15)
                                        ->appends('page', request('page'))
                                        ->appends('date', request('date'))
                                        ->appends('active', request('active'));
        }
        else{
            $movies = DB::table('movies')->paginate(15);
        }


        $yes = DB::table('movies')->where('active','=','2')
            ->join('show','show.movie_id','=', 'movies.id')
            ->select('movies.id','show.id as show_id')
            ->get();

        return view('/admin/movielist')->with('movies', $movies)->with('yes', $yes);
    }

    public function moviesearch(){
        $q = Input::get('q');
        if($q != ""){

            $movies = DB::table('movies')->where('title', 'like', '%' .$q. '%')
                        ->paginate(15)
                        ->setpath('');

            $movies->appends(array(
                'q' => Input::get('q'),
            ));

            if(count($movies) > 0){
                return view('/admin/movielist')->with('movies', $movies);
            }   
        }
        \Session::flash('error','Neboli nájdene žiadne výsledky.');
        return view('/admin/movielist');
    }

    public function insertmovieView(){
        return view('/admin/insertmovie');
    }

    public function insertshowView($id){

        $movie =  DB::table('movies')->where('id',$id)->first();
        return view('/admin/insertshow',compact('movie'))->with('id',$id);

    }

    public function showlist(){

        if(request()->has('active')){
            $shows = DB::table('movies')->where('active', request('active'))
            ->join('show','show.movie_id','=', 'movies.id')
            ->select('movies.title','show.date','show.time','show.id')
            ->paginate(15)
            ->appends('page', request('page'))
            ->appends('active', request('active'))
            ->appends('date', request('date'));

        }
        else if(request()->has('date')){

            $shows = DB::table('movies')->orderBy('show.date',request('date'))
            ->join('show','show.movie_id','=', 'movies.id')
            ->select('movies.title','show.date','show.time','show.id')
            ->paginate(15)
            ->appends('page', request('page'))
            ->appends('active', request('active'))
            ->appends('date', request('date'));

        }
        else{
            $shows = DB::table('movies')
            ->join('show','show.movie_id','=', 'movies.id')
            ->select('movies.title','show.date','show.time','show.id')
            ->paginate(15);
        }


        return view('/admin/showlist')->with('shows', $shows);
    }

    public function showsearch(){
        $q = Input::get('q');
        if (false === strtotime($q)) {
            if($q != ""){

                $shows = DB::table('movies')
                            ->join('show','show.movie_id','=', 'movies.id')
                            ->where('movies.title', 'like', '%' .$q. '%')
                            ->orWhere('show.id', 'like', '%' .$q. '%')
                            ->select('movies.title','show.date','show.time','show.id','movies.active')
                            ->paginate(15)
                            ->setpath('')
                            ->appends('page', request('page'))
                            ->appends('active', request('active'))
                            ->appends('date', request('date'));

                        //return $shows;

                $shows->appends(array(
                    'q' => Input::get('q'),
                ));

                if(count($shows) > 0){
                    return view('/admin/showlist')->with('shows', $shows);
                }   
            }
             \Session::flash('error','Neboli nájdene žiadne výsledky.');
            return view('/admin/showlist');
        }else {
            if($q != ""){

                $shows = DB::table('movies')
                            ->join('show','show.movie_id','=', 'movies.id')
                            ->where('show.date', 'like', '%' .$q. '%')
                            ->select('movies.title','show.date','show.time','show.id','movies.active')
                            ->paginate(15)
                            ->setpath('');

                        //return $shows;

                $shows->appends(array(
                    'q' => Input::get('q'),
                ));

                if(count($shows) > 0){
                    return view('/admin/showlist')->with('shows', $shows);
                }   
            }
             \Session::flash('error','Neboli nájdene žiadne výsledky.');
            return view('/admin/showlist');
        }
    }

    public function editshow($id)
    {
        $shows = DB::table('movies')
                ->join('show','show.movie_id','=', 'movies.id')->where('show.id',$id)
                ->select('movies.title','movies.active','show.date','show.time','show.id')
                ->first();
        
        return view('admin/editshow',compact('shows'))->with('id',$id);
    }

    /* Uprava filmov */

    public function updateshow(Request $request){

        $date = $request->date;
        $time = $request->time;

        if($time == 'new'){
            $time = '00:00';
        }

        $data = ['date'=>$date,
                 'time'=>$time];
        DB::table('show')->where('id',$request->id)->update($data);
        return Redirect::to('admin/showlist');
    }

    public function deleteshow($id){
        DB::table('show')->where('id',$id)->delete();
        return Redirect::to('admin/showlist');
    }
}