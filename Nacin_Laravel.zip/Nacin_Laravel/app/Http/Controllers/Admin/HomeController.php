<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input as Input;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\User;
use App\Admin;

use Auth;

/* Controller pristupu pre manazerov */

class HomeController extends Controller
{
    /* Pristup len pre manazerov */ 

    public function __construct()
    {
        $this->middleware('auth:admin');
    }

    /* Zobrazenie stranky pre pridavanie uzivatelov/manazerov */

    public function insertView(){
        return view('/admin/insert');
    }

    /* Zobrazenie zoznamu uzivatelov */

    public function userlist(){
        
        $admins = DB::table('admins')->get();

        if(request()->has('floor')){
            $users = DB::table('users')->where('floor', request('floor'))
                                        ->paginate(15)
                                        ->appends('floor', request('floor'));
        }
        else if(request()->has('buffet')){
            $users = DB::table('users')->where('buffet', request('buffet'))
                                        ->paginate(15)
                                        ->appends('buffet', request('buffet'));
        }
        else if(request()->has('pokladna')){
            $users = DB::table('users')->where('pokladna', request('pokladna'))
                                        ->paginate(15)
                                        ->appends('pokladna', request('pokladna'));
        }
        else if(request()->has('sort')){
            $users = DB::table('users')->orderBy('name',request('sort'))
                                        ->paginate(15)
                                        ->appends('sort', request('sort'));
        }
        else{
            $users = DB::table('users')->paginate(15);
        }

        return view('/admin/list')->with('users', $users)->with('admins', $admins);
    }

    /* Vyhladanie uzivatela */

    public function usersearch(){
        $q = Input::get('q');
        $admins = DB::table('admins')->get();

        if($q != ""){
            $users = DB::table('users')->where('name', 'like', '%' .$q. '%')
                        ->orWhere('email', 'like', '%' .$q. '%')
                        ->paginate(15)
                        ->setpath('');

            $users->appends(array(
                'q' => Input::get('q'),
            ));


            if(count($users) > 0){
                return view('/admin/list')->with('users', $users)->with('admins', $admins);
            }   
        }

        \Session::flash('error','Neboli nájdene žiadne výsledky.');
        return view('/admin/list')->with('admins', $admins);
    }

    public function showreservation($id){

        $reservations = DB::table('movies')->where('active','=','1')
            ->join('show','show.movie_id','=', 'movies.id')
            ->join('seat','seat.show_id','=', 'show.id')
            ->join('reservation','reservation.id','=', 'seat.reservation_id')->where('reservation.id',$id)
            ->select('movies.title','show.id as show_id','show.date','show.time','seat.id as seat_id','seat.seat','seat.row','seat.hall','reservation.id','reservation.email','reservation.created_at','reservation.expired')
            ->paginate();

            //return $reservations;


        return view('/admin/showreservation')->with('reservations', $reservations);
    }

    public function confirmreservation($id){

            $data = ['taken'=>'2'];

            DB::table('seat')->where('reservation_id',$id)->update($data);

            $data = ['paid'=>'1'];
            DB::table('reservation')->where('id',$id)->update($data);

        \Session::flash('success','Rezervácia bola potvrdená.');
        return Redirect::to('admin/reservationlist');
    }

    public function reservationlist(){

        $reservations = DB::table('reservation')->where('paid','0')->paginate(15);

        return view('/admin/reservationlist')->with('reservations', $reservations);
    }

    public function reservationsearch(){
        $q = Input::get('q');

        if($q != ""){

            if(str_contains($q, '@') == 1)
            {
                $reservations = DB::table('reservation')->where('email', 'like', '%' .$q. '%')->where('paid','0')
                        //->orWhere('created_at', 'like', '%' .$q. '%')
                        ->paginate(15)
                        ->setpath('');


                $reservations->appends(array(
                    'q' => Input::get('q'),
                ));

                if(count($reservations) > 0){
                    return view('/admin/reservationlist')->with('reservations', $reservations);
                }   
        
                \Session::flash('error','Neboli nájdene žiadne výsledky.');
                return view('/admin/reservationlist');
            }
            else if (false !== strtotime($q))
            {

                $reservations = DB::table('reservation')->where('created_at', 'like', '%' .$q. '%')->where('paid','0')
                        ->paginate(15)
                        ->setpath('');


                $reservations->appends(array(
                    'q' => Input::get('q'),
                ));

                if(count($reservations) > 0){
                    return view('/admin/reservationlist')->with('reservations', $reservations);
                }   
        
                \Session::flash('error','Neboli nájdene žiadne výsledky.');
                return view('/admin/reservationlist');
            }
            else
            {
                $reservations = DB::table('reservation')->where('id','=',$q)
                        ->paginate(15)
                        ->setpath('');


                $reservations->appends(array(
                    'q' => Input::get('q'),
                ));

                if(count($reservations) > 0){
                    return view('/admin/reservationlist')->with('reservations', $reservations);
                }   
        
                \Session::flash('error','Neboli nájdene žiadne výsledky.');
                return view('/admin/reservationlist');

            }


            
        }
    }

    public function deletereservation($id){
        DB::table('reservation')->where('id',$id)->delete();
        \Session::flash('success','Rezervácia bola potvrdená.');
        return Redirect::to('admin/reservationlist');
    }
}
