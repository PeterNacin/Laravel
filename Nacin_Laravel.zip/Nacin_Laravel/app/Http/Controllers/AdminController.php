<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Input as Input;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;
use App\User;
use App\Admin;

use Auth;

/* Controller funkcii pre manazerov */


class AdminController extends Controller
{
	/* Pristup pre manazerov */
    public function __construct()
    {
    	$this->middleware('auth:admin');
    }

    /* Zobrazenie stranky pre admina */
    public function index()
    {
    	return view('admin');
    }

    /* Stranka pre zmenu hesla */

    public function changepass(){
        return view('auth.admin_change_password');
    }

    /* Zmena hesla */ 

    public function changepassword(){
        $Admin = Admin::find(Auth::user()->id);

        if(Hash::check(Input::get('passwordold'),$Admin['password']) && Input::get('password') == Input::get('password_confirmation')){
            $Admin->password = Hash::make(Input::get('password'));
            $Admin->save();

            \Session::flash('success','Úspešne ste zmenili heslo.');
            return Redirect::to('/changepassword');
        }else{
            \Session::flash('error','NEÚspešne ste zmenili heslo.');
            return Redirect::to('admin/changepassword');
        }
    }

    /* Pridanie uzivatela */

    public function insert(Request $request){
        $name = $request->input('name');
        $email = $request->input('email');
        $phone = $request->input('phone');
        $password = $request->input('password');
        $floor = $request->input('floor');
        $buffet = $request->input('buffet');
        $pokladna = $request->input('pokladna');

        $data = array('name'=>$name,'email'=>$email,'phone'=>$phone,'password'=>Hash::make($password),'floor'=>$floor,'buffet'=>$buffet,'pokladna'=>$pokladna);

        DB::table('users')->insert($data);
        
        return Redirect::to('admin/list');
    }

    /* Pridanie manazera */

    public function insertadmin(Request $request){
        $name = $request->input('name');
        $email = $request->input('email');
        $phone = $request->input('phone');
        $password = $request->input('password');

        $data = array('name'=>$name,'email'=>$email,'password'=>Hash::make($password),'phone'=>$phone);

        DB::table('admins')->insert($data);
        
        return Redirect::to('admin/list');
    }

    /* Zmazanie uzivatela */

    public function delete($id){
        DB::table('users')->where('id',$id)->delete();
        return Redirect::to('admin/list');
    }

    /* Zmazanie admina */

    public function deleteadmin($id){
        DB::table('admins')->where('id',$id)->delete();
        return Redirect::to('admin/list');
    }

    /* Uprava informacii ako admin */

    public function editself($id)
    {
        $admin =  DB::table('admins')->where('id',$id)->first();

        return view('admin.editself',compact('admin'))->with('id',$id);
    }

    /* Update informacii ako admin */

    public function updateself(Request $request){
        $data = ['name'=>$request->name,
                 'email'=>$request->email,
                 'phone'=>$request->phone];

        DB::table('admins')->where('id',$request->id)->update($data);
        return Redirect::to('/admin');
    }

    /* Uprava informacii o uzivatelovi ako admin */

    public function edit($id)
    {
        $user =  DB::table('users')->where('id',$id)->first();

        return view('admin.edit',compact('user','admin'))->with('id',$id);
    }

    /* Uprava update o uzivatelovi ako admin */

    public function update(Request $request){

    $users = DB::table('users')->where('id',$request->id)->get();

        foreach ($users as $user) {

            $events = DB::table('events')->where('event_name', 'like','%' .$user->name. '%')->get();

            foreach ($events as $event) {

                $substring = substr($event->event_name, 0, strpos($event->event_name, ' '));
            
                $count_change = strlen($substring); // 8
                $count_event = strlen($event->event_name);  //21

                $change = substr($event->event_name, $count_change, $count_event);  // 8 - 21
                $result = $request->name . $change;

                $data = ['event_name'=>$result];
                $events = DB::table('events')->where('id',$event->id)->update($data);

                $data = ['name'=>$request->name,
                 'email'=>$request->email,
                 'phone'=>$request->phone,
                 'floor'=>$request->floor,
                 'buffet'=>$request->buffet,
                 'pokladna'=>$request->pokladna];
                DB::table('users')->where('id',$request->id)->update($data);

                $result = null;
                $substring = null;
                $change = null;
                $count_event = null;
                $count_change = null;
                $events = null;

            }

        }
        return Redirect::to('/admin/list');
    }
    
}


