<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input as Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Mail;
use App\Mail\SendMail;
use QrCode;
use QRCodeReader;
use Auth;

/* Controller pre zakaznikov */
/* Netreba autorizaciu */

class GuestController extends Controller
{
    /* Nacitanie/presmerovanie uvodnej stranky pre kazdy typ uzivatela */

    public function index()
    {
        if (Auth::user()){
            return Redirect::to('/home');
  		}elseif(auth()->guard('admin')->check() == 1){
        	return Redirect::to('/admin');
        }else{
            return Redirect::to('/movies');
        }
    }

    /* Zobrazenie filmu a saly */

    public function film($id)
    {    

        $sedadla = DB::table('seat')->where('show_id',$id)->get();

        $row = DB::table('seat')->where('show_id',$id)->orderBy('row', 'desc')->first();
        $max_row = $row->row;

        $seat = DB::table('seat')->where('show_id',$id)->orderBy('seat', 'desc')->first();
        $max_seat = $seat->seat;

        $films = DB::table('show')->where('id',$id)->get();

        return view('film',['sedadla' => $sedadla,'films' => $films])->with('max_row', $max_row)->with('max_seat', $max_seat);
    }

    /* Presmerovanie na stranku pre potvrdenie udajov k rezervacii sedadla */

    public function showInfo(Request $request){

    $id = $request->input('id');

    $movies = DB::table('movies')->where('id',$id)->get();

    return view('show',['movies' => $movies]) 
                ->with('id',$request->input('id'))
                ->with('name',$request->input('nameDisplay'))
                ->with('number',$request->input('NumberDisplay'))
                ->with('numSeats',$request->input('seatsDisplay'));
    }

    /* Update databazy pre saly, vytvorenie rezervacie, poslanie mailu, qr code */

    public function ticket(Request $request){


    $id = $request->input('id');

    //return $request->input('id');

    //$movies = DB::table('show')->where('id',$id)->get();

    //return $id;

    $movies = DB::table('movies')
                ->join('show','show.movie_id','=', 'movies.id')->where('show.id',$id)
                ->select('movies.title','movies.length','movies.genre','movies.language','show.date','show.time','show.id')
                ->get();

      
    if(!filter_var($request->input('nameDisplay'), FILTER_VALIDATE_EMAIL)) {
            return view('show',['movies' => $movies])->withErrors(['Chybná mailová adresa!', 'The Message'])->with('id',$request->input('id'))
                ->with('name',$request->input('nameDisplay'))
                ->with('number',$request->input('NumberDisplay'))
                ->with('numSeats',$request->input('seatsDisplay'));
    }

    $new = str_replace('R','',$request->input('seatsDisplay'));

    $new = str_replace('S','',$new);

    $comma_count = substr_count($new, ',');

    $ress = null;
    $res = explode(',',$new); 
    

        for ($i = 0; $i <= $comma_count; $i++){

            $mix = explode('/',$res[$i]); 

            $row = null;
            $place = null;
            $row = $mix[0];
            $place = $mix[1];

            
            $seats = DB::table('seat')->where('seat',$place)->where('row',$row)->where('show_id',$id)->get();
            foreach($seats as $seat){
                foreach($movies as $movie){
                    $check =  DB::table('seat')->where('show_id','=',$movie->id)
                                                ->where('id','=',$seat->id) 
                                                ->where('row','=',$row)
                                                ->where('seat','=',$place)
                                                ->where('taken','=','1')
                                                ->get();

                    if(count($check) > 0){
                            \Session::flash('error','Ospravedlňujeme sa, ale Vami vybrané sedadlá už boli rezervované iným zakazníkom. Vyberte si nové sedadlá.');
                                                
                        return Redirect::to('/film/'.$id);                                                   
                    }  
                }
            }
        }

        $data = array('email'=>$request->input('nameDisplay'),'paid'=>'0','expired'=>'0', 'created_at'=>date('Y/m/d H:i:s',strtotime(date('Y/m/d H:i:s')." +120 minutes")));

        DB::table('reservation')->insert($data);

        $reservations = DB::table('reservation')->where('email',$request->input('nameDisplay'))->where('paid','0')->where('created_at',date('Y/m/d H:i:s',strtotime(date('Y/m/d H:i:s')." +120 minutes")))->get();
   
        for ($i = 0; $i <= $comma_count; $i++){   

            $mix = explode('/',$res[$i]); 
            
            $row = null;
            $place = null;
            $row = $mix[0];
            $place = $mix[1];

            $seats = DB::table('seat')->where('seat',$place)->where('row',$row)->where('show_id',$id)->get();

            foreach($seats as $seat){
                foreach($reservations as $reservation){

                    $data = array('reservation_id'=>$reservation->id,'row'=>$row,'seat'=>$place,'taken'=>'1','show_id'=>$id, 'created_at'=>date('Y/m/d H:i:s',strtotime(date('Y/m/d H:i:s')." +120 minutes")));

                    DB::table('seat')->where('id',$seat->id)->update($data);

                    
                }
            }

        }
        $info = 'Rezervaciu treba potvrdit a zaplatit najneskor 10 minut pred zaciatkom filmu na pokladni!';

                    $data = 'ID: ' . $reservation->id . nl2br("\n") . $info . nl2br("\n") . 'Nazov filmu: ' . $movie->title . nl2br("\n") . 'Datum: ' . $movie->date . nl2br("\n") . 'Cas: ' . $movie->time . nl2br("\n") . 'Sala: ' . $seat->hall . nl2br("\n") . 'Sedadla: ' . $request->input('seatsDisplay');
                    QrCode::size(500)->format('png')->generate($data, public_path('images\qrcode.png')); 

                    $data = array($info,$movie->title,$movie->date,$movie->time,$seat->hall,$request->input('seatsDisplay'));
                    Mail::to('petkonacin@gmail.com')->send(new SendMail($data));

    
                \Session::flash('success','Vami vybrané sedadlá boli rezervované. Pre potvrdenie sa dostavte najneskôr 10 minút pred začiatkom filmu na pokladni. Na zadanú emailovú adresu Vám bol odoslaný email s informáciami o rezervácii.');
                return Redirect::to('/film/'.$id);
    }
}

    //return $request->all();
